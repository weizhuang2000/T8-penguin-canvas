'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

test('codex bridge signs T8 identity without exposing credentials', () => {
  process.env.T8_CODEX_BRIDGE_SECRET = 'test-secret';
  const route = require('../backend/src/routes/codex');
  const identity = route.bridgeIdentity({ id: 42, username: 'alice', email: 'alice@example.com', name: 'Alice', role: 'designer' });
  assert.ok(identity.encoded);
  assert.match(identity.signature, /^[a-f0-9]{64}$/);
  const payload = JSON.parse(Buffer.from(identity.encoded, 'base64url').toString('utf8'));
  assert.deepEqual(payload, { id: '42', username: 'alice', email: 'alice@example.com', name: 'Alice', role: 'designer', issuedAt: payload.issuedAt, expiresAt: payload.expiresAt });
  assert.doesNotMatch(identity.encoded, /apiKey|baseUrl|password/i);
});

test('codex route exposes only authenticated shared-model endpoints', () => {
  const source = require('node:fs').readFileSync(require('node:path').resolve(__dirname, '../backend/src/routes/codex.js'), 'utf8');
  assert.match(source, /router\.get\('\/models', requireCodexAuth/);
  assert.match(source, /router\.get\('\/v1\/models', requireCodexAuth/);
  assert.match(source, /router\.post\('\/v1\/chat\/completions', requireCodexAuth/);
  assert.match(source, /config\.availableModels\.includes\(model\)/);
  assert.match(source, /Authorization: `Bearer \$\{config\.apiKey\}`/);
  assert.match(source, /router\.use\(requireCodexAuth\)/);
});

test('codex workspace mount authenticates with the T8 cookie before proxying', () => {
  const source = require('node:fs').readFileSync(require('node:path').resolve(__dirname, '../backend/src/server.js'), 'utf8');
  assert.match(source, /app\.use\('\/codex', requireCookieAuth, \(req, res\) => codexRouter\.proxyToLibreChat\(req, res\)\)/);
  assert.doesNotMatch(source, /app\.use\('\/codex', codexRouter\)/);
});
