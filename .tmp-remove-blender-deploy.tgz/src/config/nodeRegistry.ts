import type { NodeMeta } from '../types/canvas';

const DEV_NODE_REGISTRY: NodeMeta[] = import.meta.env?.DEV ? [
  { type: 'rh-toolbox-maker', label: 'RH工具箱制作器', category: 'rh', description: '维护者专用：在画布内制作 RH工具箱 manifest 模板，开发环境可见，用户包不打入', icon: 'FileJson', color: 'emerald' },
  { type: 'fal-toolbox-maker', label: 'FAL应用制作工具', category: 'fal', description: '维护者专用：从 fal.ai API 文档生成 Fal超市 manifest 草稿，开发环境可见，用户包不打入', icon: 'FileJson', color: 'violet' },
] : [];

/**
 * 节点元数据注册表
 * 严格对齐 features.json 中的 24 个保留节点
 * 图标使用 lucide-react 名称(运行时由 Sidebar 动态查找)
 */
export const NODE_REGISTRY: NodeMeta[] = [
  { type: 'image-to-editable-document', label: '图片转可编辑文件', category: 'codex', description: '调用 image-to-editable-ppt Skill，把上游图片重建为对象级可编辑 PPTX 或真实分层 PSD 文件', icon: 'Layers3', color: 'sky' },
  { type: 'runninghub-video', label: 'Running 视频', category: 'rh', description: 'RunningHub 全能视频X · 图生视频低价渠道版 v1.5', icon: 'Video', color: 'cyan' },
  // ========== Input 素材资源 ==========
  { type: 'upload', label: '上传素材', category: 'input', description: '图像 / 视频 / 音频 三合一上传(自适应输出端口)', icon: 'Upload', color: 'emerald' },
  { type: 'model-3d-upload', label: '3D素材上传', category: 'input', description: '上传 glb/gltf/obj/stl/fbx/usdz/zip 3D 模型素材，并可一键生成 3D 模型预览节点', icon: 'Box', color: 'blue' },
  { type: 'model-3d-preview', label: '3D模型预览', category: 'input', description: '预览 glb/gltf/obj/stl/fbx/usdz 3D 模型，显示原始下载地址，并把当前角度快照输出为图像', icon: 'Box', color: 'blue' },
  { type: 'material-set', label: '素材集', category: 'input', description: '把多个同类型文本 / 图像 / 视频 / 音频打包成可排序素材集，可直接传给生成与 RH 节点', icon: 'Images', color: 'teal' },
  { type: 'output', label: '输出素材', category: 'input', description: '起于上游任意节点的 文本/图像/视频/音频/3D模型 结果预览(原始宽高比 + 文本双击编辑)', icon: 'MonitorPlay', color: 'teal' },

  // ========== Core 核心节点(6) ==========
  { type: 'text', label: '文本', category: 'core', description: '提示词文本节点', icon: 'Type', color: 'sky' },
  { type: 'image', label: '图像', category: 'core', description: 'GPT Image 2 / Nano Banana Pro / Nano Banana 2 (多 TAB 模型切换)', icon: 'Image', color: 'amber' },
  { type: 'fhl-image-gen', label: 'FHL 生图', category: 'core', description: 'FHL Images API 原生生图与批改：多 worker、连续生成、批量队列和工作流修复', icon: 'Images', color: 'cyan' },
  { type: 'gitee-music', label: 'ACE-Step 音乐', category: 'core', description: '通过 Gitee AI Serverless API 调用 ACE-Step-v1-3.5B 生成 30–240 秒音乐', icon: 'Music2', color: 'violet' },
  { type: 'video', label: '视频', category: 'core', description: 'Veo / Grok Video', icon: 'Video', color: 'rose' },
  { type: 'seedance', label: 'SD2.0', category: 'core', description: 'Seedance 2.0 视频分镜', icon: 'Film', color: 'fuchsia' },
  { type: 'director-storyboard', label: '导演分镜台', category: 'core', description: '秒级长片分镜台：多镜头提示词、参考素材和 Seedance2.0 无限并发生成', icon: 'Clapperboard', color: 'fuchsia' },
  { type: 'audio', label: '音频', category: 'core', description: 'Suno V5.5 全模式(生成/翻唱/续写)', icon: 'Music', color: 'violet' },
  { type: 'llm', label: 'LLM', category: 'core', description: 'GPT-5 / Claude 4.5 / Gemini 2.5(独立 Key)', icon: 'Brain', color: 'emerald' },
  { type: 'storyboard-grid', label: '分镜脚本', category: 'core', description: '文本大纲与视觉参考图生成严格等分宫格镜头，支持自动拆分和表格导出 DOCX/PDF/PPT', icon: 'Clapperboard', color: 'indigo' },
  { type: 'interactive-game-script', label: '互动游戏脚本', category: 'core', description: '面向大屏触控演示，生成可编辑 UI 界面、状态/分支互动逻辑、高清界面图与离线热点原型', icon: 'Gamepad2', color: 'cyan' },
  { type: 'prompt-reverse', label: '提示词反推', category: 'core', description: '反推 GPT Image 2 提示词，并可用接入文本替换画面内容', icon: 'BrainCircuit', color: 'emerald' },
  { type: 'remotion-animation', label: 'Remotion 动画', category: 'core', description: 'LLM 独立配置 + 内置 Skill 生成专业 TSX，经关键帧审片后本地渲染 MP4', icon: 'Clapperboard', color: 'rose' },

  // ========== RH RunningHub 节点 ==========
  { type: 'runninghub', label: 'RunningHub', category: 'rh', description: 'RH 工作流主节点', icon: 'Workflow', color: 'cyan' },
  // RH 钱包应用：复用 RunningHubNode 实现。v1.2.9.16 起与普通 RunningHub 节点统一使用 settings.rhApiKey
  { type: 'runninghub-wallet', label: 'RH钱包应用', category: 'rh', description: 'RH 钱包应用工作流（与 RunningHub 节点共用 RunningHub APIKEY）', icon: 'Wallet', color: 'violet' },
  // RH 配置节点从 v1.1.x 起隐藏（参数注入已可由 RunningHub 节点内表单代替，hidden:true 仅从 Sidebar 隐藏，保留老画布节点越。需重启删除 hidden 即可）
  { type: 'rh-config', label: 'RH 配置', category: 'rh', description: 'RH 工作流参数注入', icon: 'Settings2', color: 'cyan', hidden: true },
  // RH 工具节点 (v1.2.10+, 显示名从 v1.2.10.4 起改为「RH 超市」): 启动器式包装多个 RunningHub AI 应用，在节点内直接运行
  { type: 'rh-tools', label: 'RH超市', category: 'rh', description: '启动器式包装多个 RunningHub AI 应用，在节点内分类浏览 / 拼音搜索 / 一键运行', icon: 'Sparkles', color: 'cyan' },
  { type: 'rh-toolbox', label: 'RH工具箱', category: 'rh', description: '维护者精选 RunningHub 工具箱，只读分类运行，可作为图像/视频/文本/音频辅助能力被其他节点复用', icon: 'Wrench', color: 'cyan' },
  ...DEV_NODE_REGISTRY,

  // ========== FAL 工具箱节点 ==========
  { type: 'fal-toolbox', label: 'Fal超市', category: 'fal', description: '按分类复刻 Fal.ai 模型能力，接上游文本/图像/视频/音频后一键运行，不影响原有图像/视频 FAL 节点', icon: 'Store', color: 'violet' },

  // ========== GROK OAuth Agent ==========
  { type: 'grok-oauth-agent', label: 'Grok OAuth Agent', category: 'grok', description: '独立 Grok / xAI OAuth Agent 工作台：流式聊天、图像、视频、TTS、STT，多模态输入并输出四类素材', icon: 'Bot', color: 'emerald' },

  // ========== Codex Agent ==========
  { type: 'codex-cli-agent', label: 'Codex Agent', category: 'codex', description: '直连 LLM 独立配置的创作者 Agent：多轮对话、图像生成提示词、Skill 规范、产物库和版本树', icon: 'TerminalSquare', color: 'sky' },
  { type: 'codex-image-conjure', label: 'Codex 生图工作台', category: 'codex', description: '基于 Codex CLI imagegen 的专用生图工作台：提示词模板、片段、参考图和公共图库', icon: 'ImagePlus', color: 'sky' },
  { type: 'qoder-image-conjure', label: 'Qoder 生图工作台', category: 'qoder', description: 'Qoder CLI 编排扩展平台生图：提示词模板、片段、参考图、公共图库和任务队列', icon: 'ImagePlus', color: 'cyan' },

  // ========== Inspiration 灵感之源 ==========
  { type: 'artist-style-master', label: '艺术风格大师', category: 'exhibition', description: '移植 qiaomu 艺术家风格库：按画家、中文名、流派和标签检索，输出风格提示词、参考图或原图风格重绘', icon: 'Palette', color: 'cyan' },
  { type: 'anime-tag-master', label: '动漫标签大师', category: 'inspiration', description: '移植 comfyui-anima-t8 Danbooru / Gelbooru 懒加载图库：搜索动漫标签、参考图、保存自定义标签并输出标签或图像', icon: 'Tags', color: 'lime' },

  // ========== ComfyUI 本地工作流节点 ==========
  { type: 'comfyui-store', label: 'ComfyUI超市', category: 'comfyui', description: 'ComfyUI 应用库：导入制作好的工作流应用，接上游素材后一键运行', icon: 'Boxes', color: 'cyan' },
  { type: 'comfyui-app-maker', label: 'ComfyUI应用制作工具', category: 'comfyui', description: '上传 ComfyUI API Workflow JSON，自动识别参数并保存为可复用应用', icon: 'FileJson', color: 'emerald' },

  // ========== Special 特殊节点(4) ==========
  // 以下四个节点暂时隐藏不展示 (hidden: true) —— 需要重新启用时删除 hidden 即可。
  { type: 'multi-angle-3d', label: '多角度 3D', category: 'special', description: '3D 多视角生成', icon: 'Box', color: 'indigo', hidden: true },
  { type: 'panorama-720', label: '720 全景', category: 'special', description: '720° 全景图', icon: 'Globe', color: 'indigo', hidden: true },
  { type: 'penguin-portrait', label: '企鹅肖像', category: 'special', description: '肖像专用流程', icon: 'UserSquare2', color: 'indigo', hidden: true },
  { type: 'portrait-metadata', label: '肖像元数据', category: 'special', description: '肖像参数管理', icon: 'FileText', color: 'indigo', hidden: true },

  // ========== Utility 工具节点(13) ==========
  // 其中 4 个暂时隐藏: browser / frame-extractor / remove-bg / upscale
  { type: 'drawing-board', label: '画板', category: 'utility', description: '图层画板：接上游图片后手绘、标注、组合并输出图像', icon: 'Pencil', color: 'orange' },
  { type: 'image-edit', label: '编辑图片', category: 'utility', description: '接入原始图后打开遮罩、画板编辑窗，保存草稿并输出修改、降噪或重绘结果', icon: 'Edit3', color: 'orange' },
  { type: 'browser', label: '浏览器', category: 'utility', description: '网页内嵌', icon: 'Globe2', color: 'orange', hidden: true },
  { type: 'image-compare', label: '图像对比', category: 'utility', description: '双图滑杆 / 并排 / 叠加 / 热力 / 聚焦对比', icon: 'GitCompare', color: 'orange' },
  { type: 'frame-extractor', label: '抽帧', category: 'utility', description: '视频抽帧', icon: 'Scissors', color: 'orange', hidden: true },
  // 首尾帧获取 (v1.2.7): 输入视频节点 → 运行后抽取首帧/尾帧 → 双 image 输出
  { type: 'frame-pair', label: '首尾帧获取', category: 'utility', description: '从视频抽取首帧与尾帧，双输出可分别接下游', icon: 'Film', color: 'orange' },
  // 循环器 (v1.2.8): 上游多素材 → 串联/并联驱动下游执行链
  { type: 'loop', label: '循环器', category: 'utility', description: '接多个同类型素材，串联逐个驱动或并联克隆子图同时跱发下游生成节点', icon: 'Repeat', color: 'orange' },
  // 从合集获取 (v1.2.8): 多素材 → 按序号取单个传给下游
  { type: 'pick-from-set', label: '从合集获取', category: 'utility', description: '从上游多素材中按序号取出单一素材，kind 可在节点内切换', icon: 'Filter', color: 'orange' },
  { type: 'text-split', label: '文本分割', category: 'utility', description: '将长提示词/分镜按段落、行、智能分镜、正则、自定义分隔符或字数切成多段文本，支持收藏与循环器链路', icon: 'SplitSquareVertical', color: 'orange' },
  { type: 'import-cam-project', label: '导入项目白模', category: 'exhibition', description: '列出 C:\\cam-output 项目目录，并将选中项目 camoutput 文件夹内的图像导入为图像素材集', icon: 'Box', color: 'cyan' },
  { type: 'resize', label: '尺寸调整', category: 'utility', description: '图像尺寸调整', icon: 'Maximize2', color: 'orange' },
  { type: 'combine', label: '合并', category: 'utility', description: '图像合并', icon: 'Combine', color: 'orange' },
  { type: 'mark', label: '加标识', category: 'utility', description: '给输入图像素材在指定角落添加字符标识', icon: 'Badge', color: 'orange' },
  { type: 'remove-bg', label: '抠图', category: 'utility', description: '去除背景', icon: 'Eraser', color: 'orange', hidden: true },
  { type: 'upscale', label: '放大', category: 'utility', description: '图像放大', icon: 'ZoomIn', color: 'orange', hidden: true },
  { type: 'grid-crop', label: '宫格剪裁', category: 'utility', description: '网格切图', icon: 'Grid3x3', color: 'orange' },
  { type: 'grid-editor', label: '宫格编辑', category: 'utility', description: '多图分镜宫格拼接与顺序拆分', icon: 'LayoutGrid', color: 'orange' },

  // ========== Auxiliary 辅助节点(6) ==========
  // 其中 2 个暂时隐藏: edit / video-output
  { type: 'edit', label: '编辑', category: 'auxiliary', description: '图像编辑/局部', icon: 'Edit3', color: 'slate', hidden: true },
  { type: 'idea', label: '灵感', category: 'auxiliary', description: '灵感记录', icon: 'Lightbulb', color: 'slate' },
  { type: 'bp', label: 'BP 蓝图', category: 'auxiliary', description: 'Blueprint 蓝图', icon: 'Map', color: 'slate' },
  { type: 'relay', label: '中继', category: 'auxiliary', description: '数据中转', icon: 'ArrowRightLeft', color: 'slate' },
  { type: 'remove-ai-watermark', label: '去AI水印', category: 'auxiliary', description: '基于 remove-ai-watermarks 的可见/隐形水印、局部擦除、元数据清理与鉴别', icon: 'ShieldOff', color: 'slate' },
  { type: 'video-output', label: '视频输出', category: 'auxiliary', description: '视频结果展示', icon: 'MonitorPlay', color: 'slate', hidden: true },

  // ========== Toolbox 工具箱(6) ==========
  { type: 'cinematic', label: '电影感', category: 'toolbox', description: '电影感组合器：风格 / 镜头 / 光影 / 调色 / 质感各 50 项，支持收藏与 JSON 导入/导出', icon: 'Clapperboard', color: 'pink' },
  { type: 'video-motion', label: '视频运镜', category: 'toolbox', description: '视频运镜组合器：场景 / 动作 / 路径 / 节奏 / 稳定 / 主体约束各 50 项，支持收藏与 JSON 导入/导出', icon: 'Camera', color: 'pink' },
  { type: 'elevation-prompt', label: '立面提示词', category: 'exhibition', description: '解析 DOCX / 文本 PDF / TXT，AI 提炼内容并生成彩立面概念 Prompt 与准确图文工艺排版清单', icon: 'PanelsTopLeft', color: 'cyan' },
  { type: 'exhibition-img2img', label: '展陈图生图', category: 'exhibition', description: '双参考图展陈图生图：结构示意图 + 空间表现效果图，支持工艺版式与优先级控制', icon: 'Boxes', color: 'cyan' },
  { type: 'exhibition-style-transfer', label: '风格迁移', category: 'exhibition', description: '展陈空间风格迁移：原始图像结构不变，仅迁移设计风格、色彩、材质与表面质感', icon: 'Shuffle', color: 'cyan' },
  { type: 'exhibition-recolor', label: '主色调更换', category: 'exhibition', description: '展陈空间主色调更换：输入原始图像，使用主色、辅助色、点缀色和明暗度进行语义换色，并保护指定展品对象', icon: 'Palette', color: 'cyan' },
  { type: 'exhibition-lighting-heatmap', label: '灯光热力图', category: 'exhibition', description: '展陈空间灯光热力分析：输入图像后生成覆盖层或独立伪彩色光照热力图，支持模型、尺寸和格式选择', icon: 'ThermometerSun', color: 'cyan' },
  { type: 'exhibition-creative-image', label: '展陈创意生图', category: 'exhibition', description: '面向序厅、尾厅和重亮点展项空间：单空间图约束建筑空间，LLM 创意描述后多次图生图', icon: 'Layers3', color: 'cyan' },
  { type: 'exhibition-render-to-elevation', label: '效果图转立面', category: 'exhibition', description: '接入效果图和立面文本，LLM 识别立面1/2/3并逐张生成独立立面图', icon: 'PanelsTopLeft', color: 'cyan' },
  { type: 'exhibition-text-image-loop', label: '图文循环器', category: 'exhibition', description: '同步接入文本和图像素材集，按一一配对 / 短集循环 / 全组合驱动下游展陈生图节点', icon: 'Repeat2', color: 'cyan' },
  { type: 'exhibition-outline-split', label: '展陈大纲拆分', category: 'exhibition', description: '读取展陈资料文档，按指定单元数或自动模式拆分大纲并提炼总结，输出多段文本', icon: 'ListTree', color: 'cyan' },
  { type: 'unit-panel-design', label: '单元板设计', category: 'exhibition', description: '生成单元板/整套板式设计图：两级文字提炼、多语言排序、材质选择、色材参考和尺寸标注', icon: 'PanelsTopLeft', color: 'cyan' },
  { type: 'sculpture-relief-design', label: '雕塑/浮雕设计', category: 'exhibition', description: '展陈雕塑与浮雕设计：文案提炼、类型选择、尺寸材质控制和参考图案轮廓约束', icon: 'Landmark', color: 'cyan' },
  { type: 'exhibition-wayfinding-design', label: '导视系统设计', category: 'exhibition', description: '博物馆室内外导视系统：导览标牌、方向牌、楼层索引、无障碍与安全导视的规范图和效果图生成', icon: 'MapPinned', color: 'cyan' },
  { type: 'exhibition-scene-design', label: '场景设计', category: 'exhibition', description: '展馆场景设计：场景分类、整体环境参考、人物道具 @ 引用和图像生成', icon: 'Theater', color: 'cyan' },
  { type: 'science-exhibit-design', label: '科技展项设计', category: 'exhibition', description: '科技馆展项设计：LLM 提炼真实科学原理与参数，一键生成效果图、爆炸图、原理图、三视图和参数表', icon: 'Atom', color: 'cyan' },
  { type: 'exhibition-floorplan-layout', label: '展陈平面布局', category: 'exhibition', description: 'DXF/截图建筑底图锁定、规则排布、三套候选、约束校验和 AI 平面表现图', icon: 'LayoutDashboard', color: 'cyan' },
  { type: 'showcase-interior-design', label: '柜内设计', category: 'exhibition', description: '展柜内部陈列设计：展柜尺寸、展品图与展品高度、色彩材质预设、尺寸标注和爆炸图输出', icon: 'Archive', color: 'cyan' },
  { type: 'reverse-isometric-design', label: '反推轴侧', category: 'exhibition', description: '以平面布局约束墙柱、出入口和门窗，手动排布展项并生成无顶展陈轴侧图', icon: 'Boxes', color: 'cyan' },
  { type: 'fusion-render-design', label: '融合效果图', category: 'exhibition', description: '可选平面布局或空白矩形空间，手动排布展项并生成写实展陈空间透视效果图', icon: 'Sparkles', color: 'cyan' },
  { type: 'cinema-auditorium-design', label: '影院报告厅设计', category: 'exhibition', description: '影院、报告厅和特效影院空间设计：长宽高、银幕舞台方向、色彩材质预设，输出效果图、彩平图和系统设备原理图', icon: 'Theater', color: 'cyan' },
  { type: 'multi-angle-visual', label: '可视化多角度', category: 'toolbox', description: '可视化调节方位 / 俯仰 / 远近，支持批量角度、Prompt 模式、前后缀、镜头收藏、JSON 导入/导出与紧凑双栏 UI', icon: 'Compass', color: 'pink' },
  { type: 'portrait-master', label: '肖像大师', category: 'toolbox', description: '捏人 Prompt 设计器：五官、发型、服饰、配饰、气质神情等 9 大类词库，支持随机、锁定、权重和运行输出文本', icon: 'UserRoundCog', color: 'pink' },
  { type: 'pose-master', label: '姿势大师', category: 'toolbox', description: '人体线稿姿态编辑器：支持多人姿势、抓取移动、OpenPose/COCO 预览输出、keypoints JSON 与中英文 prompt', icon: 'PersonStanding', color: 'pink' },
  { type: 'aggregate-parser', label: '聚合解析', category: 'toolbox', description: '基于 ParseHub 的轻量自媒体聚合解析：输入短链/分享码/分享文案，合规确认后默认保存到输出目录；远端地址解析作为高级模式保留', icon: 'Link2', color: 'pink' },
  { type: 'batch-processor', label: '批量素材处理', category: 'toolbox', description: '批量导入文件或文件夹，在节点内完成命名、去黑边、抠图、扩图、高清放大和进度反馈，不自动铺满画布输出节点', icon: 'Files', color: 'pink' },
  { type: 'seedvr2-upscale', label: 'SeedVR2超分', category: 'core', description: '调用 SeedVR2-7B 对单张上游图像做 AI 超分，支持倍数/目标尺寸、种子、颜色校正、缩放算法和 JPG/PNG 保存格式', icon: 'ImageUp', color: 'cyan' },
  { type: 'topaz-image-upscale', label: 'Topaz图像高清化', category: 'toolbox', description: '调用本机 Topaz Gigapixel AI / Gigapixel 8，对上游图像做本地高清放大；需要用户已安装并登录软件', icon: 'Image', color: 'pink' },
  { type: 'topaz-video-upscale', label: 'Topaz视频高清化', category: 'toolbox', description: '调用本机 Topaz Video AI 自带 ffmpeg，对上游视频做放大与补帧；需要用户已安装并登录软件', icon: 'Video', color: 'pink' },

  // ========== 3D 节点 ==========
  { type: 'panorama-3d', label: '3D全景', category: '3d', description: 'Three.js 360 全景预览与取景导出，内置 GPT Image 2 文生/图生 21:9 全景贴图生成', icon: 'Globe2', color: 'sky' },
];

// 按分类分组,便于 Sidebar 渲染 (在这里过滤 hidden 节点 —— 它们仍在 NODE_REGISTRY 中保证节点类型注册)
export const NODE_GROUPS: Record<string, { label: string; nodes: NodeMeta[] }> = {
  input: { label: '素材资源', nodes: NODE_REGISTRY.filter((n) => n.category === 'input' && !n.hidden) },
  core: { label: '核心节点', nodes: NODE_REGISTRY.filter((n) => n.category === 'core' && !n.hidden) },
  exhibition: { label: '展陈工具', nodes: NODE_REGISTRY.filter((n) => n.category === 'exhibition' && !n.hidden) },
  rh: { label: 'RH', nodes: NODE_REGISTRY.filter((n) => n.category === 'rh' && !n.hidden) },
  fal: { label: 'FAL工具箱', nodes: NODE_REGISTRY.filter((n) => n.category === 'fal' && !n.hidden) },
  grok: { label: 'GROK OAuth', nodes: NODE_REGISTRY.filter((n) => n.category === 'grok' && !n.hidden) },
  codex: { label: 'CODEX CLI', nodes: NODE_REGISTRY.filter((n) => n.category === 'codex' && !n.hidden) },
  qoder: { label: 'QODER CLI', nodes: NODE_REGISTRY.filter((n) => n.category === 'qoder' && !n.hidden) },
  inspiration: { label: '灵感之源', nodes: NODE_REGISTRY.filter((n) => n.category === 'inspiration' && !n.hidden) },
  comfyui: { label: 'ComfyUI', nodes: NODE_REGISTRY.filter((n) => n.category === 'comfyui' && !n.hidden) },
  special: { label: '特殊节点', nodes: NODE_REGISTRY.filter((n) => n.category === 'special' && !n.hidden) },
  utility: { label: '工具节点', nodes: NODE_REGISTRY.filter((n) => n.category === 'utility' && !n.hidden) },
  auxiliary: { label: '辅助节点', nodes: NODE_REGISTRY.filter((n) => n.category === 'auxiliary' && !n.hidden) },
  toolbox: { label: '工具箱', nodes: NODE_REGISTRY.filter((n) => n.category === 'toolbox' && !n.hidden) },
  '3d': { label: '3D', nodes: NODE_REGISTRY.filter((n) => n.category === '3d' && !n.hidden) },
};

// 通过 type 反查 meta
export function getNodeMeta(type: string): NodeMeta | undefined {
  return NODE_REGISTRY.find((n) => n.type === type);
}
