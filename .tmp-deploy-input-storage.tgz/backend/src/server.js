const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const { requireAuth, requireCookieAuth } = require('./auth/middleware');
const { startFigmaBridgeOnAppStart } = require('./utils/figmaBridge');
const { serveOutputFile, serveInputFile, startOutputStorageManager } = require('./outputStorage/manager');
const { startPptService, stopPptService } = require('./pptServiceManager');
const { migrateLegacyImageDimensions } = require('./utils/generationHistory');
const { flushPendingWrites } = require('./utils/monitoringMetrics');

const app = express();
const CAM_OUTPUT_IMAGE_RE = /\.(png|jpe?g|webp|gif|bmp|avif|tiff?)$/i;
const IMMUTABLE_PRIVATE_MEDIA_CACHE = 'private, max-age=31536000, immutable';
const immutableMediaStaticOptions = {
  maxAge: '1y',
  immutable: true,
  setHeaders(res) {
    // Uploaded/generated filenames are unique. Let an authenticated browser reuse them without
    // opening a new HTTP/2 stream every time a historical canvas is revisited.
    res.setHeader('Cache-Control', IMMUTABLE_PRIVATE_MEDIA_CACHE);
  },
};

// ========== 中间件 ==========
const LOCAL_ORIGIN_RE = /^https?:\/\/(?:127\.0\.0\.1|localhost)(?::\d+)?$/;
app.use(cors({
  origin(origin, cb) {
    cb(null, !origin || LOCAL_ORIGIN_RE.test(origin));
  },
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// 简易访问日志
app.use((req, _res, next) => {
  const t = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  console.log(`[${t}] ${req.method} ${req.path}`);
  next();
});

// ========== 目录初始化 ==========
[
  config.DATA_DIR,
  config.INPUT_DIR,
  config.OUTPUT_DIR,
  config.THUMBNAILS_DIR,
].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ========== 静态资源托管 ==========
function isPathInside(root, target) {
  const base = path.resolve(root);
  const resolved = path.resolve(target);
  return resolved === base || resolved.startsWith(base + path.sep);
}

function cleanCamPathPart(value) {
  const text = String(value || '').trim();
  if (!text || text === '.' || text === '..') return '';
  if (text.includes('/') || text.includes('\\') || text.includes('\0')) return '';
  return text;
}

app.get('/files/cam-output/:project/:filename', requireAuth, (req, res) => {
  const project = cleanCamPathPart(req.params.project);
  const filename = cleanCamPathPart(req.params.filename);
  if (!project || !filename || !CAM_OUTPUT_IMAGE_RE.test(filename)) {
    return res.status(400).json({ success: false, error: 'Invalid cam-output path' });
  }
  const root = path.resolve(config.CAM_OUTPUT_ROOT);
  const projectDir = path.resolve(root, project);
  const folder = path.resolve(projectDir, 'camoutput');
  const file = path.resolve(folder, filename);
  if (!isPathInside(root, projectDir) || !isPathInside(projectDir, folder) || !isPathInside(folder, file)) {
    return res.status(400).json({ success: false, error: 'Invalid cam-output path' });
  }
  if (!fs.existsSync(file)) {
    return res.status(404).json({ success: false, error: 'Cam output image not found' });
  }
  return res.sendFile(file);
});

app.get('/files/output/*', requireAuth, serveOutputFile);
app.head('/files/output/*', requireAuth, serveOutputFile);
app.use('/files/input', requireAuth, express.static(config.INPUT_DIR, immutableMediaStaticOptions));
app.get('/files/input/*', requireAuth, serveInputFile);
app.head('/files/input/*', requireAuth, serveInputFile);
app.use('/files/thumbnails', requireAuth, express.static(config.THUMBNAILS_DIR, immutableMediaStaticOptions));
app.get('/output/*', requireAuth, serveOutputFile);
app.head('/output/*', requireAuth, serveOutputFile);
app.use('/input', requireAuth, express.static(config.INPUT_DIR, immutableMediaStaticOptions));
app.get('/input/*', requireAuth, serveInputFile);
app.head('/input/*', requireAuth, serveInputFile);

// ========== 健康检查 ==========
app.get('/api/status', (_req, res) => {
  res.json({
    ok: true,
    service: 't8-penguin-canvas-backend',
    version: config.APP_VERSION,
    port: config.PORT,
    time: new Date().toISOString(),
  });
});

// ========== 业务路由 ==========
const canvasRouter = require('./routes/canvas');
const authRouter = require('./routes/auth');
const adminRouter = require('./routes/admin');
const settingsRouter = require('./routes/settings');
const proxyRouter = require('./routes/proxy');
const filesRouter = require('./routes/files');
const imageOpsRouter = require('./routes/imageOps');
const resourcesRouter = require('./routes/resources');
const themesRouter = require('./routes/themes');
const eagleRouter = require('./routes/eagle');
const figmaRouter = require('./routes/figma');
const externalProvidersRouter = require('./routes/externalProviders');
const grokOAuthRouter = require('./routes/grokOAuth');
const codexCliRouter = require('./routes/codexCli');
const qoderCliRouter = require('./routes/qoderCli');
const aiWatermarkRouter = require('./routes/aiWatermark');
const generationHistoryRouter = require('./routes/generationHistory');
const promptLibraryRouter = require('./routes/promptLibrary');
const documentsRouter = require('./routes/documents');
const cloudUploadsRouter = require('./routes/cloudUploads');
const parseHubRouter = require('./routes/parseHub');
const achievementsRouter = require('./routes/achievements');
const topazRouter = require('./routes/topaz');
const animeTagsRouter = require('./routes/animeTags');
const nodeHelpRouter = require('./routes/nodeHelp');
const floorplanRouter = require('./routes/floorplan');
const remotionRouter = require('./routes/remotion');
const outputStorageRouter = require('./routes/outputStorage');
const pptProxyRouter = require('./routes/pptProxy');
const notificationsRouter = require('./routes/notifications');
const fhlImageRouter = require('./routes/fhlImage');
const monitoringRouter = require('./routes/monitoring');
const codexRouter = require('./routes/codex');
const seedvr2Router = require('./routes/seedvr2');
const { registerLocalExtensions } = require('./extensions/localExtensions');
const localHooks = require('./extensions/runtimeHooks');

app.use('/api/auth', authRouter);
app.use('/api/ppt', pptProxyRouter);
app.use('/internal/qoder-cli', qoderCliRouter.internalRouter);
app.use('/api', (req, res, next) => {
  if (req.path === '/status' || req.path.startsWith('/auth/')) return next();
  if (req.path.startsWith('/codex/')
    && config.CODEX_BRIDGE_SECRET
    && req.headers['x-t8-codex-internal'] === config.CODEX_BRIDGE_SECRET) return next();
  return requireAuth(req, res, next);
});

app.use('/api/canvas', canvasRouter);
app.use('/api/admin', adminRouter);
app.use('/api/settings', settingsRouter);
app.use('/api/proxy', proxyRouter);
app.use('/api/proxy/external', externalProvidersRouter);
app.use('/api/files', filesRouter);
app.use('/api/image', imageOpsRouter);
app.use('/api/resources', resourcesRouter);
app.use('/api/themes', themesRouter);
app.use('/api/eagle', eagleRouter);
app.use('/api/figma', figmaRouter);
app.use('/api/grok-oauth', grokOAuthRouter);
app.use('/api/codex-cli', codexCliRouter);
app.use('/api/qoder-cli', qoderCliRouter);
app.use('/api/ai-watermark', aiWatermarkRouter);
app.use('/api/generation-history', generationHistoryRouter);
app.use('/api/prompt-library', promptLibraryRouter);
app.use('/api/documents', documentsRouter);
app.use('/api/cloud-uploads', cloudUploadsRouter);
app.use('/api/parsehub', parseHubRouter);
app.use('/api/achievements', achievementsRouter);
app.use('/api/topaz', topazRouter);
app.use('/api/anime-tags', animeTagsRouter);
app.use('/api/node-help', nodeHelpRouter);
app.use('/api/floorplan', floorplanRouter);
app.use('/api/remotion', remotionRouter);
app.use('/api/output-storage', outputStorageRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/fhl-image', fhlImageRouter);
app.use('/api/monitoring', monitoringRouter);
app.use('/api/seedvr2', seedvr2Router);
app.use('/api/codex', codexRouter);
app.use('/codex', requireCookieAuth, (req, res) => codexRouter.proxyToLibreChat(req, res));
registerLocalExtensions(app, { config, express, logger: console, hooks: localHooks });

// ========== 前端静态资源(仅打包模式) ==========
// 开发模式下不启用,避免与 Vite dev server 打架。
if (config.IS_PACKAGED && config.FRONTEND_DIST && fs.existsSync(config.FRONTEND_DIST)) {
  app.use(express.static(config.FRONTEND_DIST));
  // SPA 兑底: 除了 /api/* 与 /files/* 外,其他路由返回 index.html(允许前端路由)
  app.get(/^\/(?!api\/|files\/|input\/|output\/).*/, (_req, res) => {
    res.sendFile(path.join(config.FRONTEND_DIST, 'index.html'));
  });
}

// ========== 启动 ==========
const PORT = config.PORT;
const HOST = config.HOST;

app.listen(PORT, HOST, () => {
  void migrateLegacyImageDimensions();
  startPptService().catch((error) => console.warn('[ppt] startup failed:', error?.message || error));
  startOutputStorageManager();
  console.log('==================================================');
  console.log('🐧 T8-penguin-canvas 后端服务');
  console.log('==================================================');
  console.log(`🚀 服务器启动成功!`);
  console.log(`   地址: http://${HOST}:${PORT}`);
  console.log(`   环境: ${config.NODE_ENV}`);
  console.log(`   数据目录: ${config.DATA_DIR}`);
  console.log(`   输出目录: ${config.OUTPUT_DIR}`);
  console.log('   Figma Bridge: 自动启动中（如需禁用可设置 T8_FIGMA_BRIDGE_AUTOSTART=0）');
  console.log('   按 Ctrl+C 停止服务器...');
  console.log('--------------------------------------------------');
  startFigmaBridgeOnAppStart(console);
});

process.once('SIGINT', () => { flushPendingWrites(); stopPptService(); });
process.once('SIGTERM', () => { flushPendingWrites(); stopPptService(); });
