#!/bin/bash
# Execute one PPT job with Codex. The prompt is passed through stdin so it is
# not exposed in the process list.
set -euo pipefail

echo "[ppt-runner] job=${JOB_ID:-?} resume=${RESUME_SESSION:-0} ts=$(date -u +%FT%TZ)" >&2

if [ -z "${PROMPT:-}" ]; then
  echo "[ppt-runner] ERROR: PROMPT env is required" >&2
  exit 2
fi

FULL_PROMPT="${PROMPT}"
if [ -n "${EXTRA_PROMPT:-}" ]; then
  FULL_PROMPT="${PROMPT}

${EXTRA_PROMPT}"
fi

ARGS=(exec --json --sandbox workspace-write -c 'approval_policy="never"' --skip-git-repo-check)
if [ -n "${T8_PPT_CODEX_BASE_URL:-}" ]; then
  # Use the selected T8 LLM independent configuration through a private
  # Codex model provider. The API key is passed only via env_key.
  ARGS+=(--model "${T8_PPT_CODEX_MODEL:-gpt-4.1}" \
    -c 'model_provider="t8_ppt_llm"' \
    -c 'model_providers.t8_ppt_llm.name="T8 LLM Config"' \
    -c "model_providers.t8_ppt_llm.base_url=\"${T8_PPT_CODEX_BASE_URL%/}/v1\"" \
    -c 'model_providers.t8_ppt_llm.wire_api="responses"' \
    -c 'model_providers.t8_ppt_llm.env_key="CODEX_API_KEY"' \
    -c 'model_providers.t8_ppt_llm.requires_openai_auth=false' \
    -c 'disable_response_storage=true')
fi
if [ -n "${T8_PPT_CODEX_MODEL:-}" ]; then
  ARGS+=(--model "${T8_PPT_CODEX_MODEL}")
fi
if [ "${RESUME_SESSION:-0}" = "1" ] && [ -n "${RESUME_SESSION_ID:-}" ]; then
  ARGS+=(resume "${RESUME_SESSION_ID}")
fi

cd /opt/ppt-master
echo "[ppt-runner] exec: codex ${ARGS[*]} -" >&2
exec codex "${ARGS[@]}" - <<< "${FULL_PROMPT}"
