import{k as v,r as ce,j as n}from"./xyflow-eyWz-w8m.js";import{d7 as Ce,d4 as Mt,_ as Ft,bd as Tt,a9 as vt,P as He,fz as At,aq as Rt,eZ as Te,eg as Ot,fV as Kt,et as nt,ed as Zt,dE as Bt,ex as se,ew as Ne,b8 as wt,b4 as Jt,eu as be,c4 as st,cN as it,c8 as Ae,cg as Gt,cr as Dt,E as Ut,b$ as rt,ev as ot,co as Ht,cz as Wt,bK as yt,au as at,ak as Vt,az as qt,dJ as Xt,e3 as Yt,eM as Qt,ez as en,dc as tn,df as nn,aY as sn,d0 as rn,gE as on,gD as an,ea as ln,bz as cn,e_ as un,es as dn,$ as pn,bg as mn,eq as hn}from"./index-CBRWgy-b.js";function fn(e){const t=String(e||""),i=t.length===0?1:t.split(/\r\n|\r|\n/).length;return{chars:t.length,lines:i}}async function gn(e){var t;if(typeof navigator<"u"&&((t=navigator.clipboard)!=null&&t.writeText)){await navigator.clipboard.writeText(e);return}typeof window<"u"&&window.prompt("复制文本:",e)}function xn(e){const t=JSON.parse(e||"{}");return JSON.stringify(t,null,2)}function bn(e){JSON.parse(e||"{}")}function vn(e){const t=new Set;return String(e||"").split(/\r\n|\r|\n/).map(r=>r.trim()).filter(Boolean).filter(r=>{const o=r.toLowerCase();return t.has(o)?!1:(t.add(o),!0)}).join(`
`)}function wn({open:e,title:t,value:i,onValueChange:r,onApply:o,onCancel:c,placeholder:a,isDark:f,isPixel:l,readOnly:d=!1,mono:k=!1,editorKind:p="text",children:m}){const w=v.useMemo(()=>fn(i),[i]),[x,h]=v.useState("");if(v.useEffect(()=>{e&&h("")},[e]),v.useEffect(()=>{if(!e)return;const _=b=>{if(b.key==="Escape"&&!b.ctrlKey&&!b.metaKey&&!b.altKey&&!b.shiftKey){b.preventDefault(),b.stopPropagation(),c();return}(b.ctrlKey||b.metaKey)&&b.key==="Enter"&&(b.preventDefault(),b.stopPropagation(),d||o())};return window.addEventListener("keydown",_,!0),()=>window.removeEventListener("keydown",_,!0)},[o,c,e,d]),!e||typeof document>"u")return null;const E=l?"px-card text-[var(--px-ink)]":`rounded-lg border shadow-2xl ${f?"border-white/10 bg-zinc-950 text-zinc-100":"border-black/10 bg-white text-zinc-900"}`,N=l?"px-btn px-btn--sm":`inline-flex h-8 items-center justify-center gap-1.5 rounded-md border px-3 text-xs font-semibold transition-colors ${f?"border-white/10 hover:bg-white/10":"border-black/10 hover:bg-black/5"}`,y=l?"px-btn px-btn--sm px-btn--yellow":"inline-flex h-8 items-center justify-center gap-1.5 rounded-md bg-cyan-400 px-3 text-xs font-bold text-slate-950 hover:bg-cyan-300",$=l?"px-input h-full w-full resize-none text-sm leading-relaxed":`h-full w-full resize-none rounded-md border px-3 py-2 text-sm leading-relaxed outline-none ${f?"border-white/10 bg-white/5 text-white placeholder:text-white/30 focus:border-cyan-300/60":"border-black/10 bg-black/[0.03] text-zinc-900 placeholder:text-zinc-400 focus:border-cyan-500/70"} ${k?"font-mono":""}`,S=l?"px-btn px-btn--sm":`inline-flex h-8 items-center justify-center gap-1.5 rounded-md border px-3 text-xs font-semibold transition-colors ${f?"border-white/10 bg-white/[0.03] hover:bg-white/10":"border-black/10 bg-black/[0.02] hover:bg-black/5"}`,B=()=>{try{const _=xn(i);r(_),h("JSON 已格式化")}catch(_){h(`JSON 格式错误：${(_==null?void 0:_.message)||"无法解析"}`)}},J=()=>{try{bn(i),h("JSON 格式正确")}catch(_){h(`JSON 格式错误：${(_==null?void 0:_.message)||"无法解析"}`)}},G=()=>{r(vn(i)),h("已整理为空行去重列表")};return ce.createPortal(n.jsx("div",{"data-canvas-floating-ui":"prompt-expand-editor",className:"fixed inset-0 z-[10080] flex items-center justify-center bg-black/45 p-3",onMouseDown:c,children:n.jsxs("section",{className:`${E} flex h-[min(82vh,860px)] w-[min(1080px,calc(100vw-24px))] flex-col overflow-hidden`,onMouseDown:_=>_.stopPropagation(),role:"dialog","aria-modal":"true","aria-label":t||"放大编辑提示词",children:[n.jsxs("header",{className:`flex items-center justify-between gap-3 px-4 py-3 ${l?"border-b-2 border-[var(--px-ink)]":f?"border-b border-white/10":"border-b border-black/10"}`,children:[n.jsxs("div",{className:"min-w-0",children:[n.jsx("div",{className:"truncate text-sm font-bold",children:t||"放大编辑提示词"}),n.jsxs("div",{className:`mt-0.5 text-[11px] ${l?"text-[var(--px-ink)] opacity-70":f?"text-white/45":"text-zinc-500"}`,children:[w.chars," 字 · ",w.lines," 行 · Alt+Enter 打开 · Ctrl+Enter 完成 · Esc 取消"]})]}),n.jsx("button",{type:"button",className:N,onClick:c,title:"关闭",children:n.jsx(Ce,{size:14})})]}),n.jsxs("main",{className:"flex min-h-0 flex-1 flex-col p-4",children:[p!=="text"&&n.jsxs("div",{className:"mb-3 flex flex-wrap items-center gap-2",children:[p==="json"&&n.jsxs(n.Fragment,{children:[n.jsxs("button",{type:"button",className:S,onClick:B,disabled:d,children:[n.jsx(Mt,{size:13})," 格式化 JSON"]}),n.jsxs("button",{type:"button",className:S,onClick:J,children:[n.jsx(Ft,{size:13})," 校验 JSON"]})]}),p==="lines"&&n.jsxs("button",{type:"button",className:S,onClick:G,disabled:d,children:[n.jsx(Tt,{size:13})," 整理列表"]}),x&&n.jsx("span",{className:`text-[11px] ${x.includes("错误")?"text-red-400":f?"text-cyan-200":"text-cyan-700"}`,children:x})]}),m||n.jsx("textarea",{autoFocus:!0,readOnly:d,value:i,onChange:_=>r(_.target.value),placeholder:a,className:$,spellCheck:!1})]}),n.jsxs("footer",{className:`flex flex-wrap items-center justify-between gap-2 px-4 py-3 ${l?"border-t-2 border-[var(--px-ink)]":f?"border-t border-white/10":"border-t border-black/10"}`,children:[n.jsx("div",{className:`text-[11px] ${l?"text-[var(--px-ink)] opacity-70":f?"text-white/45":"text-zinc-500"}`,children:d?"当前字段为只读，可查看或复制。":"完成后会写回原节点字段。"}),n.jsxs("div",{className:"flex items-center gap-2",children:[n.jsxs("button",{type:"button",className:N,onClick:()=>gn(i),title:"复制当前文本",children:[n.jsx(vt,{size:13})," 复制"]}),n.jsx("button",{type:"button",className:N,onClick:c,children:"取消"}),n.jsxs("button",{type:"button",className:`${y} ${d?"opacity-45":""}`,disabled:d,onClick:o,children:[n.jsx(He,{size:13})," 完成"]})]})]})]})}),document.body)}const ae={width:320,height:240},lt=.8,ve=12,ct=12;function le(e,t){return Number.isFinite(e)&&e>0?e:t}function ut(e,t,i){return i<t?t:Math.min(Math.max(e,t),i)}function yn(e,t){const i=le((e==null?void 0:e.width)??0,ae.width),r=le((e==null?void 0:e.height)??0,ae.height),o=Math.max(80,Math.floor(le(t.width,ae.width)*lt)),c=Math.max(80,Math.floor(le(t.height,ae.height)*lt)),a=Math.min(1,o/i,c/r);return{width:Math.max(1,Math.round(i*a)),height:Math.max(1,Math.round(r*a))}}function jn(e,t,i){const r=yn(t,i),o=le(i.width,ae.width),c=le(i.height,ae.height),a=o-ve-r.width,f=c-ve-r.height,l=e.right+ct,d=e.left-ct-r.width,p=l+r.width<=o-ve?l:d;return{left:ut(p,ve,a),top:ut(e.top,ve,f),width:r.width,height:r.height}}function kn(e){return{left:e.left,top:e.top,right:e.right,bottom:e.bottom,width:e.width,height:e.height}}function _n({src:e,alt:t,buttonClassName:i="",iconSize:r=14,title:o="悬停预览100%"}){const c=v.useRef(null),[a,f]=v.useState(!1),[l,d]=v.useState(null),[k,p]=v.useState(null),m=v.useCallback(()=>{var y;const N=(y=c.current)==null?void 0:y.getBoundingClientRect();N&&d(kn(N))},[]),w=v.useCallback(()=>{m(),At(e).catch(()=>{}),f(!0)},[e,m]),x=v.useCallback(()=>{f(!1)},[]);v.useEffect(()=>{p(null),f(!1)},[e]),v.useEffect(()=>{if(a)return m(),window.addEventListener("resize",m),window.addEventListener("scroll",m,!0),()=>{window.removeEventListener("resize",m),window.removeEventListener("scroll",m,!0)}},[a,m]);const h=v.useMemo(()=>!a||!l||typeof window>"u"?null:jn(l,k,{width:window.innerWidth,height:window.innerHeight}),[l,k,a]),E=h?{left:h.left,top:h.top,width:h.width,height:h.height}:void 0;return n.jsxs(n.Fragment,{children:[n.jsx("button",{ref:c,type:"button",className:`nodrag nopan t8-btn t8-mini-icon-button t8-image-preview-trigger ${i}`,title:o,"aria-label":o,onPointerEnter:w,onPointerMove:m,onPointerLeave:x,onFocus:w,onBlur:x,onPointerDown:N=>{N.preventDefault(),N.stopPropagation()},onMouseDown:N=>{N.preventDefault(),N.stopPropagation()},onClick:N=>{N.preventDefault(),N.stopPropagation()},children:n.jsx(Rt,{size:r})}),a&&h&&typeof document<"u"?ce.createPortal(n.jsx("div",{className:"t8-image-preview-popover",style:E,children:n.jsx("img",{className:"t8-image-preview-popover__image",src:e,alt:t||o,width:h.width,height:h.height,onLoad:N=>{const y=N.currentTarget;p({width:y.naturalWidth,height:y.naturalHeight})}})}),document.body):null]})}function Nn(e){return[e.titleZh,e.titleEn,e.descriptionZh,e.descriptionEn,e.promptZh,e.promptEn,e.negativeZh,e.negativeEn,e.tags.join(" "),e.ownerName||"",e.ownerUserId||"",(e.attachments||[]).map(t=>t.title||t.url).join(" "),e.source].join(" ").toLowerCase()}async function dt(e){var t;if(typeof navigator<"u"&&((t=navigator.clipboard)!=null&&t.writeText)){await navigator.clipboard.writeText(e);return}typeof window<"u"&&window.prompt("复制文本:",e)}function In(e,t){if(typeof document>"u")return;const i=new Blob([JSON.stringify(t,null,2)],{type:"application/json;charset=utf-8"}),r=URL.createObjectURL(i),o=document.createElement("a");o.href=r,o.download=e,document.body.appendChild(o),o.click(),o.remove(),URL.revokeObjectURL(r)}function Re(e,t){return e==="image"?t==="en"?"Image":"图像":t==="en"?"Video":"视频"}function pt(e,t){return e.source==="custom"?t==="en"?"Mine":"我的":t==="en"?"Built-in":"内置"}function Cn(e){return e==="admin"||e==="manager"}function mt(e){return(e==null?void 0:e.name)||(e==null?void 0:e.username)||(e==null?void 0:e.id)||""}function oe(e){return e==="image"?"image-portrait-character":"video-cinematic-shot"}function Oe(e,t,i,r=!1){var o;return{id:e&&r?e.id:void 0,kind:(e==null?void 0:e.kind)||t,categoryId:(e==null?void 0:e.categoryId)||i||oe(t),titleZh:e&&r?e.titleZh:e?`${e.titleZh} 副本`:"我的提示词模板",titleEn:e&&r?e.titleEn:e?`${e.titleEn||e.titleZh} Copy`:"My Prompt Template",descriptionZh:(e==null?void 0:e.descriptionZh)||"",descriptionEn:(e==null?void 0:e.descriptionEn)||"",promptZh:(e==null?void 0:e.promptZh)||"",promptEn:(e==null?void 0:e.promptEn)||(e==null?void 0:e.promptZh)||"",negativeZh:(e==null?void 0:e.negativeZh)||"",negativeEn:(e==null?void 0:e.negativeEn)||(e==null?void 0:e.negativeZh)||"",tags:((o=e==null?void 0:e.tags)==null?void 0:o.join(", "))||"",attachments:(e==null?void 0:e.attachments)||[]}}function ht(e){return e==="image"?"图像":e==="video"?"视频":"音频"}function $n(e){return e==="image"?n.jsx(sn,{size:12}):e==="video"?n.jsx(rn,{size:12}):n.jsx(yt,{size:12})}function En({open:e,initialKind:t,value:i,onApply:r,onClose:o,isDark:c,isPixel:a,currentUser:f}){var Qe,et;const l=v.useRef(null),[d,k]=v.useState(()=>Te()),[p,m]=v.useState(t),[w,x]=v.useState("all"),[h,E]=v.useState(d.language||"zh"),[N,y]=v.useState(""),[$,S]=v.useState("all"),[B,J]=v.useState(""),[G,_]=v.useState(""),[b,L]=v.useState(null),[Le,pe]=v.useState(""),[T,X]=v.useState(f||null),Y=Cn(T==null?void 0:T.role),V=String((T==null?void 0:T.id)||"");v.useEffect(()=>{if(e){const s=Te();k(s),E(s.language||"zh"),m(t),_(""),L(null),f?X(f):Ot().then(X).catch(()=>X(null))}},[f,t,e]),v.useEffect(()=>{if(!e)return;const s=()=>{const u=Te();k(u)};return window.addEventListener("penguin:prompt-templates-changed",s),()=>window.removeEventListener("penguin:prompt-templates-changed",s)},[e]);const U=v.useCallback(s=>{k(u=>Kt(s(u)))},[]),Q=v.useMemo(()=>nt(p,d.customCategories),[p,d.customCategories]);v.useEffect(()=>{w!=="all"&&!Q.some(s=>s.id===w)&&x("all")},[Q,w]);const me=v.useMemo(()=>new Set(d.hiddenBuiltInIds),[d.hiddenBuiltInIds]),q=v.useMemo(()=>Zt(),[]),he=v.useMemo(()=>q.filter(s=>!me.has(s.id)),[q,me]),ee=v.useMemo(()=>new Set(q.map(s=>s.id)),[q]),te=v.useMemo(()=>{const s=new Map(d.customItems.map(I=>[I.id,I])),u=he.map(I=>s.get(I.id)||I),C=d.customItems.filter(I=>!ee.has(I.id));return[...u,...C]},[he,ee,d.customItems]),fe=v.useMemo(()=>{const s={};return te.filter(u=>u.kind===p).forEach(u=>{s[u.categoryId]=(s[u.categoryId]||0)+1}),s},[p,te]),Se=v.useMemo(()=>Bt(),[]),A=v.useMemo(()=>{const s=N.trim().toLowerCase();return te.filter(u=>u.kind===p).filter(u=>w==="all"||u.categoryId===w).filter(u=>$==="all"||($==="mine"?u.source==="custom"&&!!u.ownerUserId&&String(u.ownerUserId)===V:u.source!=="custom"||ee.has(u.id))).filter(u=>!s||Nn(u).includes(s)).sort((u,C)=>{const I=K=>K.source==="infinite-canvas"?0:K.source==="custom"?1:2;return I(u)-I(C)||se(u,h).localeCompare(se(C,h))}).slice(0,320)},[p,te,ee,w,V,h,N,$]),g=v.useMemo(()=>A.find(s=>s.id===B)||A[0]||null,[B,A]),ne=!!g&&(Y||g.source==="custom"&&!!g.ownerUserId&&String(g.ownerUserId)===V),ge=!!g&&ne,je=!!T;if(v.useEffect(()=>{A.length&&!A.some(s=>s.id===B)&&J(A[0].id),!A.length&&B&&J("")},[B,A]),v.useEffect(()=>{if(!e)return;const s=u=>{u.key==="Escape"&&(u.preventDefault(),o())};return window.addEventListener("keydown",s,!0),()=>window.removeEventListener("keydown",s,!0)},[o,e]),!e||typeof document>"u")return null;const Pe=a?"px-card text-[var(--px-ink)]":`rounded-xl border shadow-2xl ${c?"border-white/10 bg-zinc-950 text-zinc-100":"border-black/10 bg-white text-zinc-900"}`,P=a?"px-btn px-btn--sm":`inline-flex h-8 items-center justify-center gap-1.5 rounded-md border px-3 text-xs font-semibold transition-colors ${c?"border-white/10 hover:bg-white/10":"border-black/10 hover:bg-black/5"}`,ke=a?"px-btn px-btn--sm px-btn--yellow":"inline-flex h-8 items-center justify-center gap-1.5 rounded-md bg-cyan-400 px-3 text-xs font-bold text-slate-950 hover:bg-cyan-300",R=a?"px-input":`rounded-md border px-3 py-2 text-sm outline-none ${c?"border-white/10 bg-white/5 text-white placeholder:text-white/35":"border-black/10 bg-black/[0.03] text-zinc-900 placeholder:text-zinc-400"}`,M=a?"opacity-70":c?"text-white/55":"text-zinc-500",ze=s=>{E(s),U(u=>({...u,language:s}))},xe=s=>{if(!g)return;const u=Ne(g,h,s==="full");if(s==="append"){const C=i.trim();r(C?`${C}
${u}`:u)}else r(u);o()},j=()=>{if(!(b!=null&&b.promptZh.trim())||!b.titleZh.trim()){_("模板名称和提示词不能为空");return}if(!je){_("请先登录后再创建模板");return}const s=!!b.id,u=Xt({id:b.id,kind:b.kind,categoryId:b.categoryId||oe(b.kind),titleZh:b.titleZh,titleEn:b.titleEn,descriptionZh:b.descriptionZh,descriptionEn:b.descriptionEn,promptZh:b.promptZh,promptEn:b.promptEn,negativeZh:b.negativeZh,negativeEn:b.negativeEn,tags:b.tags.split(/[,，\n]/).map(C=>C.trim()).filter(Boolean),attachments:b.attachments,owner:T?{id:T.id,name:mt(T)}:null});U(C=>{const I=C.customItems.some(K=>K.id===u.id);return{...C,customItems:I?C.customItems.map(K=>K.id===u.id?{...u,createdAt:K.createdAt}:K):[u,...C.customItems.filter(K=>K.id!==u.id)],hiddenBuiltInIds:C.hiddenBuiltInIds.filter(K=>K!==u.id)}}),J(u.id),m(u.kind),x(u.categoryId),L(null),_(s?"模板已更新":"模板已保存到我的模板")},O=()=>{if(!i.trim()){_("当前输入框为空，无法保存为模板");return}const s=w==="all"?oe(p):w;L(Oe({id:"",kind:p,categoryId:s,titleZh:"来自当前输入框",titleEn:"From Current Prompt",descriptionZh:"从当前节点提示词保存",descriptionEn:"Saved from the current node prompt",promptZh:i,promptEn:i,negativeZh:"",negativeEn:"",tags:["我的模板"]},p,s))},Me=()=>{if(g){if(g.source==="custom"){if(!ge){_("没有权限删除这个模板");return}if(!window.confirm(`删除模板「${se(g,h)}」？`))return;U(s=>({...s,customItems:s.customItems.filter(u=>u.id!==g.id)})),_("模板已删除");return}if(!Y){_("普通用户只能隐藏内置模板，不能真正删除");return}window.confirm(`隐藏内置模板「${se(g,h)}」？可通过“恢复内置”找回。`)&&(U(s=>({...s,hiddenBuiltInIds:Array.from(new Set([...s.hiddenBuiltInIds,g.id]))})),_("内置模板已隐藏"))}},_e=()=>{if(!je){_("请先登录后再创建分类");return}const s=window.prompt(p==="image"?"新建图像模板分类":"新建视频模板分类");if(!(s!=null&&s.trim()))return;const u=`custom-${p}-${Date.now().toString(36)}`,C={id:u,kind:p,labelZh:s.trim(),labelEn:s.trim(),descriptionZh:"我的提示词分类",descriptionEn:"My prompt category",order:1e3+d.customCategories.length,builtIn:!1,ownerUserId:V,ownerName:mt(T)};U(I=>({...I,customCategories:[...I.customCategories,C]})),x(u)},$t=s=>{if(s.builtIn||s.ownerUserId&&s.ownerUserId!==V&&!Y)return;const u=window.prompt("重命名分类",h==="en"?s.labelEn:s.labelZh);u!=null&&u.trim()&&U(C=>({...C,customCategories:C.customCategories.map(I=>I.id===s.id?{...I,labelZh:u.trim(),labelEn:u.trim()}:I)}))},Et=s=>{if(s.builtIn||s.ownerUserId&&s.ownerUserId!==V&&!Y||!window.confirm(`删除分类「${be(s,h)}」？其中我的模板会移动到默认分类。`))return;const u=oe(s.kind);U(C=>({...C,customCategories:C.customCategories.filter(I=>I.id!==s.id),customItems:C.customItems.map(I=>I.categoryId===s.id?{...I,categoryId:u}:I)})),x("all")},Lt=()=>{In("t8-prompt-template-library.json",Yt(d)),_("已导出我的模板库 JSON")},St=async s=>{if(s)try{const u=await s.text(),C=JSON.parse(u),I=Qt(C,d,"merge");k(I),_(`已导入模板：${I.customItems.length} 个我的模板`)}catch(u){_((u==null?void 0:u.message)||"导入失败")}finally{l.current&&(l.current.value="")}},Pt=async()=>{var s;if(g){pe("resource");try{let u="";const C=await en("set");if(C.success&&(u=((s=C.data.find(H=>/提示词|prompt/i.test(H.name)))==null?void 0:s.id)||""),!u){const H=await tn("set","提示词模板");H.success&&(u=H.data.id)}const I=se(g,h),K=h==="en"?g.promptEn||g.promptZh:g.promptZh||g.promptEn,tt=h==="en"?g.negativeEn||g.negativeZh||"":g.negativeZh||g.negativeEn||"",Fe=await nn({materialSetKind:"text",categoryId:u||void 0,title:`提示词模板 · ${I}`,tags:["提示词模板",Re(g.kind,"zh"),g.categoryId,...g.tags].slice(0,20),materialSetItems:[{kind:"text",name:"正向提示词",text:K},...tt?[{kind:"text",name:"负向提示词",text:tt}]:[],...(g.attachments||[]).map(H=>({kind:H.kind,name:H.title||ht(H.kind),url:H.url,mime:H.mime})),{kind:"text",name:"模板信息",text:JSON.stringify({id:g.id,kind:g.kind,categoryId:g.categoryId,titleZh:g.titleZh,titleEn:g.titleEn,source:g.source,tags:g.tags},null,2)}]});if(!Fe.success)throw new Error(Fe.error||"保存资源库失败");window.dispatchEvent(new CustomEvent("penguin:resources-changed")),_(Fe.duplicate?"资源库已有相同模板，已更新分类":"已保存到资源库")}catch(u){_((u==null?void 0:u.message)||"保存到资源库失败")}finally{pe("")}}},Xe=Q.find(s=>s.id===w)||null,Ye=g?Ne(g,h,!1):"",zt=g?Ne(g,h,!0):"";return ce.createPortal(n.jsx("div",{"data-canvas-floating-ui":"prompt-template-library",className:"fixed inset-0 z-[10140] flex items-center justify-center bg-black/50 p-3",onMouseDown:o,children:n.jsxs("section",{className:`${Pe} flex h-[min(88vh,900px)] w-[min(1180px,calc(100vw-24px))] flex-col overflow-hidden`,role:"dialog","aria-modal":"true","aria-label":"提示词模板库",onMouseDown:s=>s.stopPropagation(),children:[n.jsxs("header",{className:`flex items-center justify-between gap-3 px-4 py-3 ${a?"border-b-2 border-[var(--px-ink)]":c?"border-b border-white/10":"border-b border-black/10"}`,children:[n.jsxs("div",{className:"min-w-0",children:[n.jsxs("div",{className:"flex items-center gap-2 text-sm font-bold",children:[n.jsx(wt,{size:16}),n.jsx("span",{children:"提示词模板库"})]}),n.jsx("div",{className:`mt-0.5 text-[11px] ${M}`,children:"图像 / 视频双库 · 我的模板可带图像 / 视频 / 音频附件 · 支持导入导出、资源库保存"})]}),n.jsxs("div",{className:"flex items-center gap-2",children:[n.jsxs("button",{type:"button",className:P,onClick:()=>ze(h==="zh"?"en":"zh"),title:"中英文切换",children:[n.jsx(Jt,{size:13})," ",h==="zh"?"中文":"EN"]}),n.jsx("button",{type:"button",className:P,onClick:o,title:"关闭",children:n.jsx(Ce,{size:14})})]})]}),n.jsxs("div",{className:"grid grid-cols-[190px_minmax(260px,330px)_minmax(0,1fr)] gap-0 min-h-0 flex-1 ",children:[n.jsxs("aside",{className:`min-h-0 overflow-y-auto p-3 ${a?"border-r-2 border-[var(--px-ink)] bg-[var(--px-muted)]":c?"border-r border-white/10 bg-white/[0.02]":"border-r border-black/10 bg-black/[0.02]"}`,children:[n.jsx("div",{className:"grid grid-cols-2 gap-2",children:["image","video"].map(s=>n.jsx("button",{type:"button",className:a?`px-btn px-btn--sm ${p===s?"px-btn--yellow":""}`:`h-9 rounded-md border text-xs font-bold ${p===s?"border-cyan-300 bg-cyan-400 text-slate-950":c?"border-white/10 hover:bg-white/10":"border-black/10 hover:bg-black/5"}`,onClick:()=>{m(s),x("all"),J("")},children:Re(s,h)},s))}),n.jsxs("button",{type:"button",className:`mt-3 w-full text-left ${a?"px-btn px-btn--sm":`rounded-md px-2 py-2 text-xs font-bold ${w==="all"?"bg-cyan-400 text-slate-950":c?"hover:bg-white/10":"hover:bg-black/5"}`}`,onClick:()=>x("all"),children:["全部 ",n.jsxs("span",{className:"opacity-60",children:["(",te.filter(s=>s.kind===p).length,")"]})]}),n.jsx("div",{className:"mt-2 space-y-1",children:Q.map(s=>{const u=s.id===w;return n.jsxs("div",{className:"group flex items-center gap-1",children:[n.jsxs("button",{type:"button",className:`min-w-0 flex-1 rounded-md px-2 py-1.5 text-left text-xs ${u?a?"border-2 border-[var(--px-ink)] bg-[var(--px-yellow)]":"bg-cyan-500/15 text-cyan-300":c?"hover:bg-white/10":"hover:bg-black/5"}`,onClick:()=>x(s.id),title:be(s,h),children:[n.jsx("span",{className:"block truncate font-bold",children:be(s,h)}),n.jsxs("span",{className:`block text-[10px] ${M}`,children:[fe[s.id]||0," · 内置 ",Se[s.id]||0]})]}),!s.builtIn&&n.jsxs("div",{className:"hidden shrink-0 group-hover:flex",children:[n.jsx("button",{type:"button",className:"p-1 opacity-70 hover:opacity-100",onClick:()=>$t(s),title:"重命名",children:n.jsx(st,{size:11})}),n.jsx("button",{type:"button",className:"p-1 text-red-400 opacity-70 hover:opacity-100",onClick:()=>Et(s),title:"删除",children:n.jsx(it,{size:11})})]})]},s.id)})}),n.jsxs("button",{type:"button",className:`mt-3 w-full ${P}`,onClick:_e,children:[n.jsx(Ae,{size:13})," 分类"]}),Y&&d.hiddenBuiltInIds.length>0&&n.jsxs("button",{type:"button",className:`mt-2 w-full ${P}`,onClick:()=>{U(s=>({...s,hiddenBuiltInIds:[]})),_("已恢复隐藏的内置模板")},children:[n.jsx(Gt,{size:13})," 恢复内置"]})]}),n.jsxs("section",{className:`min-h-0 overflow-hidden p-3 ${a?"border-r-2 border-[var(--px-ink)]":c?"border-r border-white/10":"border-r border-black/10"}`,children:[n.jsxs("div",{className:"space-y-2",children:[n.jsxs("div",{className:"relative",children:[n.jsx(Dt,{size:14,className:`absolute left-2.5 top-1/2 -translate-y-1/2 ${M}`}),n.jsx("input",{value:N,onChange:s=>y(s.target.value),placeholder:"搜索模板 / 标签 / Prompt",className:`${R} h-9 w-full pl-8`})]}),n.jsx("div",{className:"grid grid-cols-3 gap-2",children:["all","builtin","mine"].map(s=>n.jsx("button",{type:"button",className:a?`px-btn px-btn--sm ${$===s?"px-btn--yellow":""}`:`h-8 rounded-md border text-[11px] font-bold ${$===s?"border-cyan-300 bg-cyan-400 text-slate-950":c?"border-white/10 hover:bg-white/10":"border-black/10 hover:bg-black/5"}`,onClick:()=>S(s),children:s==="all"?"全部":s==="builtin"?"内置":"我的"},s))}),n.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[n.jsxs("button",{type:"button",className:P,onClick:O,children:[n.jsx(Ut,{size:13})," 存当前"]}),n.jsxs("button",{type:"button",className:P,onClick:()=>L(Oe(null,p,w==="all"?oe(p):w)),children:[n.jsx(Ae,{size:13})," 新模板"]})]})]}),n.jsx("div",{className:"mt-3 min-h-0 overflow-y-auto pr-1",style:{height:"calc(100% - 126px)"},children:A.length===0?n.jsx("div",{className:`flex h-52 items-center justify-center rounded border border-dashed text-xs ${M}`,children:"没有匹配模板"}):n.jsx("div",{className:"space-y-2",children:A.map(s=>{var C,I;const u=(g==null?void 0:g.id)===s.id;return n.jsxs("button",{type:"button",className:`w-full rounded-lg border p-2 text-left transition ${u?a?"border-[var(--px-ink)] bg-[var(--px-yellow)]":"border-cyan-300 bg-cyan-400/10":c?"border-white/10 bg-white/[0.03] hover:bg-white/[0.07]":"border-black/10 bg-black/[0.025] hover:bg-black/[0.05]"}`,onClick:()=>J(s.id),children:[n.jsxs("div",{className:"flex items-start justify-between gap-2",children:[n.jsx("span",{className:"min-w-0 truncate text-xs font-bold",children:se(s,h)}),n.jsxs("span",{className:`flex shrink-0 items-center gap-1 text-[10px] ${M}`,children:[(((C=s.attachments)==null?void 0:C.length)||0)>0&&n.jsxs("span",{className:"inline-flex items-center gap-0.5",children:[n.jsx(rt,{size:10})," ",(I=s.attachments)==null?void 0:I.length]}),pt(s,h),s.source==="custom"&&s.ownerName?` · ${s.ownerName}`:""]})]}),n.jsx("div",{className:`mt-1 line-clamp-2 text-[10px] leading-relaxed ${M}`,children:ot(s,h)||Ne(s,h).slice(0,120)})]},s.id)})})})]}),n.jsxs("main",{className:"flex min-h-0 flex-col p-3",children:[G&&n.jsx("div",{className:`mb-2 rounded px-2 py-1 text-[11px] ${a?"border-2 border-[var(--px-ink)] bg-[var(--px-yellow)]":c?"bg-white/10 text-white/75":"bg-black/5 text-zinc-600"}`,children:G}),b?n.jsxs("div",{className:"flex min-h-0 flex-1 flex-col gap-2",children:[n.jsxs("div",{className:"flex items-center justify-between gap-2",children:[n.jsx("div",{className:"text-sm font-bold",children:b.id?"编辑我的模板":"新建我的模板"}),n.jsxs("button",{type:"button",className:P,onClick:()=>L(null),children:[n.jsx(Ce,{size:13})," 取消"]})]}),n.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[n.jsx("input",{className:R,value:b.titleZh,onChange:s=>L({...b,titleZh:s.target.value}),placeholder:"中文名称"}),n.jsx("input",{className:R,value:b.titleEn,onChange:s=>L({...b,titleEn:s.target.value}),placeholder:"English title"}),n.jsxs("select",{className:R,value:b.kind,onChange:s=>{const u=s.target.value;L({...b,kind:u,categoryId:oe(u)})},children:[n.jsx("option",{value:"image",children:"图像模板"}),n.jsx("option",{value:"video",children:"视频模板"})]}),n.jsx("select",{className:R,value:b.categoryId,onChange:s=>L({...b,categoryId:s.target.value}),children:nt(b.kind,d.customCategories).map(s=>n.jsx("option",{value:s.id,children:be(s,h)},s.id))})]}),n.jsx("textarea",{className:`${R} min-h-[58px] resize-none`,value:b.descriptionZh,onChange:s=>L({...b,descriptionZh:s.target.value}),placeholder:"中文说明"}),n.jsx("textarea",{className:`${R} min-h-[58px] resize-none`,value:b.descriptionEn,onChange:s=>L({...b,descriptionEn:s.target.value}),placeholder:"English description"}),n.jsxs("div",{className:"grid min-h-0 flex-1 grid-cols-2 gap-2",children:[n.jsx("textarea",{className:`${R} min-h-[220px] resize-none`,value:b.promptZh,onChange:s=>L({...b,promptZh:s.target.value}),placeholder:"中文正向提示词"}),n.jsx("textarea",{className:`${R} min-h-[220px] resize-none`,value:b.promptEn,onChange:s=>L({...b,promptEn:s.target.value}),placeholder:"English positive prompt"}),n.jsx("textarea",{className:`${R} min-h-[110px] resize-none`,value:b.negativeZh,onChange:s=>L({...b,negativeZh:s.target.value}),placeholder:"中文负向提示词（可选）"}),n.jsx("textarea",{className:`${R} min-h-[110px] resize-none`,value:b.negativeEn,onChange:s=>L({...b,negativeEn:s.target.value}),placeholder:"English negative prompt (optional)"})]}),n.jsx("input",{className:R,value:b.tags,onChange:s=>L({...b,tags:s.target.value}),placeholder:"标签，用逗号分隔"}),b.attachments.length>0&&n.jsxs("div",{className:`rounded border px-2 py-1.5 text-[11px] ${a?"border-[var(--px-ink)] bg-[var(--px-muted)]":c?"border-white/10 bg-white/[0.03] text-white/60":"border-black/10 bg-black/[0.025] text-zinc-500"}`,children:["已关联 ",b.attachments.length," 个配套素材，保存文字修改时会一并保留。"]}),n.jsxs("div",{className:"flex justify-end gap-2",children:[n.jsx("button",{type:"button",className:P,onClick:()=>L(null),children:"取消"}),n.jsxs("button",{type:"button",className:ke,onClick:j,children:[n.jsx(Ht,{size:13})," 保存模板"]})]})]}):g?n.jsxs(n.Fragment,{children:[n.jsxs("div",{className:"flex items-start justify-between gap-3",children:[n.jsxs("div",{className:"min-w-0",children:[n.jsx("div",{className:"truncate text-base font-bold",children:se(g,h)}),n.jsxs("div",{className:`mt-1 text-[11px] ${M}`,children:[Re(g.kind,h)," · ",Xe?be(Xe,h):g.categoryId," · ",pt(g,h)]})]}),n.jsxs("div",{className:"flex shrink-0 items-center gap-2",children:[n.jsxs("button",{type:"button",className:P,onClick:()=>L(Oe(g,p,g.categoryId,ne)),title:ne?"编辑":"复制后编辑",children:[n.jsx(st,{size:13})," ",ne?"编辑":"复制"]}),ge&&n.jsxs("button",{type:"button",className:P,onClick:Me,title:g.source==="custom"?"删除":"隐藏",children:[n.jsx(it,{size:13})," ",g.source==="custom"?"删除":"隐藏"]})]})]}),n.jsx("div",{className:`mt-3 rounded-lg border p-3 text-xs leading-relaxed ${a?"border-[var(--px-ink)] bg-[var(--px-muted)]":c?"border-white/10 bg-white/[0.03]":"border-black/10 bg-black/[0.025]"}`,children:ot(g,h)}),(((Qe=g.attachments)==null?void 0:Qe.length)||0)>0&&n.jsxs("div",{"data-prompt-template-media-preview":!0,className:`mt-3 rounded-lg border p-3 ${a?"border-[var(--px-ink)] bg-[var(--px-muted)]":c?"border-white/10 bg-white/[0.03]":"border-black/10 bg-black/[0.025]"}`,children:[n.jsxs("div",{className:`mb-2 flex items-center justify-between gap-2 text-[10px] font-bold ${M}`,children:[n.jsxs("span",{className:"inline-flex items-center gap-1.5",children:[n.jsx(rt,{size:12})," 配套素材"]}),n.jsxs("span",{children:[((et=g.attachments)==null?void 0:et.length)||0," 项 · 仅加载当前模板"]})]}),n.jsx("div",{className:"grid grid-cols-2 gap-2 xl:grid-cols-3",children:(g.attachments||[]).map(s=>n.jsxs("div",{className:`overflow-hidden rounded-md border ${a?"border-[var(--px-ink)] bg-[var(--px-surface)]":c?"border-white/10 bg-black/20":"border-black/10 bg-white/70"}`,children:[n.jsx("div",{className:"group/prompt-media relative h-28 overflow-hidden bg-black/80",children:s.kind==="image"?n.jsxs(n.Fragment,{children:[n.jsx(Wt,{src:s.previewUrl||s.url,alt:s.title||"配套图像",className:"h-full w-full object-contain",thumbSize:360,draggable:!1}),n.jsx(_n,{src:s.url,alt:s.title||"配套图像",buttonClassName:"absolute right-1.5 top-1.5 z-10 h-7 w-7 p-0 opacity-0 shadow-md transition group-hover/prompt-media:opacity-100 focus:opacity-100"})]}):s.kind==="video"?n.jsx("video",{src:s.url,poster:s.previewUrl,controls:!0,preload:"metadata",className:"h-full w-full object-contain"}):n.jsxs("div",{className:"flex h-full w-full flex-col items-center justify-center gap-2 px-2 text-white",children:[n.jsx(yt,{size:28}),n.jsx("audio",{src:s.url,controls:!0,preload:"none",className:"w-full"})]})}),n.jsxs("div",{className:`flex items-center gap-1.5 px-2 py-1.5 text-[10px] ${M}`,children:[$n(s.kind),n.jsx("span",{className:"min-w-0 flex-1 truncate",title:s.title||s.url,children:s.title||s.url.split("/").pop()||ht(s.kind)})]})]},s.id))})]}),n.jsx("div",{className:"mt-3 grid min-h-0 flex-1 grid-cols-1 gap-3 overflow-hidden",children:n.jsxs("div",{className:"min-h-0 overflow-y-auto rounded-lg border p-3 text-xs leading-relaxed whitespace-pre-wrap select-text",style:{borderColor:a?"var(--px-ink, #1a1410)":c?"rgba(255,255,255,.10)":"rgba(0,0,0,.10)",background:a?"var(--px-surface, #fff7df)":c?"rgba(255,255,255,.04)":"rgba(0,0,0,.025)"},children:[n.jsx("div",{className:`mb-2 text-[10px] font-bold ${M}`,children:"正向提示词"}),Ye,(h==="en"?g.negativeEn||g.negativeZh:g.negativeZh||g.negativeEn)&&n.jsxs(n.Fragment,{children:[n.jsx("div",{className:`mb-2 mt-4 text-[10px] font-bold ${M}`,children:"负向提示词"}),h==="en"?g.negativeEn||g.negativeZh:g.negativeZh||g.negativeEn]})]})}),n.jsxs("div",{className:"mt-3 flex flex-wrap items-center justify-between gap-2",children:[n.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[n.jsxs("button",{type:"button",className:P,onClick:()=>dt(Ye),children:[n.jsx(vt,{size:13})," 复制正向"]}),n.jsxs("button",{type:"button",className:P,onClick:()=>dt(zt),children:[n.jsx(at,{size:13})," 复制正负"]}),n.jsxs("button",{type:"button",className:P,onClick:Pt,disabled:Le==="resource",children:[n.jsx(Vt,{size:13})," ",Le==="resource"?"保存中":"资源库"]})]}),n.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[n.jsxs("button",{type:"button",className:P,onClick:()=>xe("append"),children:[n.jsx(Ae,{size:13})," 追加"]}),n.jsxs("button",{type:"button",className:P,onClick:()=>xe("full"),children:[n.jsx(He,{size:13})," 正负向"]}),n.jsxs("button",{type:"button",className:ke,onClick:()=>xe("replace"),children:[n.jsx(He,{size:13})," 替换"]})]})]})]}):n.jsx("div",{className:`flex flex-1 items-center justify-center text-sm ${M}`,children:"请选择或新建一个模板"})]})]}),n.jsxs("footer",{className:`flex items-center justify-between gap-2 px-4 py-3 ${a?"border-t-2 border-[var(--px-ink)]":c?"border-t border-white/10":"border-t border-black/10"}`,children:[n.jsx("div",{className:`text-[11px] ${M}`,children:"内置模板来自 T8 生成库、Infinite-Canvas 种子模板与公开提示词写法规律；我的模板保存在本机，可导入导出迁移。"}),n.jsxs("div",{className:"flex items-center gap-2",children:[n.jsx("input",{ref:l,type:"file",accept:"application/json,.json",className:"hidden",onChange:s=>{var u;return void St(((u=s.target.files)==null?void 0:u[0])||null)}}),n.jsxs("button",{type:"button",className:P,onClick:()=>{var s;return(s=l.current)==null?void 0:s.click()},children:[n.jsx(qt,{size:13})," 导入"]}),n.jsxs("button",{type:"button",className:P,onClick:Lt,children:[n.jsx(at,{size:13})," 导出"]})]})]})]})}),document.body)}const es=v.forwardRef(function({value:t,onValueChange:i,title:r,containerClassName:o="relative",isDark:c,isPixel:a,mono:f=!1,editorKind:l="text",promptTemplateKind:d=!1,compact:k=!1,compactHeight:p=36,className:m,style:w,onKeyDown:x,onBeforeInput:h,onCompositionStart:E,onCompositionEnd:N,placeholder:y,readOnly:$,...S},B){const J=v.useRef(null),G=v.useRef(!1),_=v.useRef(!1),{theme:b,style:L}=on(),pe=an(j=>j.shortcuts)["editor.expand-prompt"],T=c??b==="dark",X=a??L==="pixel",[Y,V]=v.useState(!1),[U,Q]=v.useState(!1),[me,q]=v.useState(t||""),[he,ee]=v.useState(t||""),te=ln(pe),fe=d!==!1,Se=d||"image";v.useEffect(()=>{if(_.current){_.current=!1;return}G.current||q(t||"")},[t]);const A=j=>{_.current=!0,ce.flushSync(()=>{q(j)}),$||i(j)},g=j=>{const O=j;return!!(O!=null&&O.isComposing)||/Composition/i.test(String((O==null?void 0:O.inputType)||""))},ne=()=>{ee(me||""),V(!0)},ge=()=>{V(!1),window.setTimeout(()=>{var j;return(j=J.current)==null?void 0:j.focus()},0)},je=()=>{A(he),ge()},Pe=j=>{if(G.current||j.nativeEvent.isComposing){x==null||x(j);return}if(un(pe,j.nativeEvent)){j.preventDefault(),j.stopPropagation(),ne();return}x==null||x(j)},P=j=>{g(j.nativeEvent)&&(G.current=!0),h==null||h(j)},ke=j=>{G.current=!0,E==null||E(j)},R=j=>{N==null||N(j);const O=j.currentTarget.value;window.setTimeout(()=>{var _e;const Me=((_e=J.current)==null?void 0:_e.value)??O;G.current=!1,A(Me)},0)},M=X?"px-btn px-btn--icon px-btn--ghost":`rounded border p-1 shadow-sm ${T?"border-white/10 bg-zinc-950/80 text-white/70 hover:text-white":"border-black/10 bg-white/90 text-zinc-600 hover:text-zinc-900"}`,ze=k?{...w,height:p,minHeight:p,maxHeight:p,resize:"none",overflowX:"auto",overflowY:"hidden",whiteSpace:"nowrap",paddingRight:(w==null?void 0:w.paddingRight)??(fe?64:34)}:fe?{...w,paddingRight:(w==null?void 0:w.paddingRight)??64}:w,xe=j=>{J.current=j,typeof B=="function"?B(j):B&&(B.current=j)};return n.jsxs("div",{className:o,children:[n.jsx("textarea",{...S,ref:xe,value:me,readOnly:$,onBeforeInput:P,onCompositionStart:ke,onCompositionEnd:R,onChange:j=>{const O=j.target.value;if(G.current||g(j.nativeEvent)){q(O);return}_.current=!0,ce.flushSync(()=>{q(O)}),$||i(O)},onKeyDown:Pe,placeholder:y,className:m,style:ze,wrap:k?"off":S.wrap,spellCheck:!1}),fe&&n.jsx("button",{type:"button","data-prompt-template-trigger":!0,className:`nodrag nopan absolute top-1.5 z-10 inline-flex h-6 w-6 items-center justify-center ${M}`,style:{right:34},onMouseDown:j=>{j.preventDefault(),j.stopPropagation()},onClick:j=>{j.preventDefault(),j.stopPropagation(),Q(!0)},title:"提示词模板库","aria-label":"提示词模板库",children:n.jsx(wt,{size:12})}),n.jsx("button",{type:"button","data-prompt-expand-trigger":!0,className:`nodrag nopan absolute right-1.5 top-1.5 z-10 inline-flex h-6 w-6 items-center justify-center ${M}`,onMouseDown:j=>{j.preventDefault(),j.stopPropagation()},onClick:j=>{j.preventDefault(),j.stopPropagation(),ne()},title:`放大编辑 (${te})`,"aria-label":"放大编辑",children:n.jsx(cn,{size:12})}),n.jsx(wn,{open:Y,title:r,value:he,onValueChange:ee,onApply:je,onCancel:ge,placeholder:typeof y=="string"?y:void 0,isDark:T,isPixel:X,readOnly:!!$,mono:f||l==="json",editorKind:l}),n.jsx(En,{open:U,initialKind:Se,value:t||"",onApply:j=>{A(j)},onClose:()=>{Q(!1),window.setTimeout(()=>{var j;return(j=J.current)==null?void 0:j.focus()},0)},isDark:T,isPixel:X})]})}),Ln="t8-comfyui-field-exclude-rules",ts=[{value:"prompt",label:"正向 Prompt"},{value:"negative",label:"负向 Prompt"},{value:"image1",label:"上游图片 1"},{value:"image2",label:"上游图片 2"},{value:"image3",label:"上游图片 3"},{value:"image4",label:"上游图片 4"},{value:"image5",label:"上游图片 5"},{value:"image6",label:"上游图片 6"},{value:"video1",label:"上游视频 1"},{value:"video2",label:"上游视频 2"},{value:"video3",label:"上游视频 3"},{value:"audio1",label:"上游音频 1"},{value:"audio2",label:"上游音频 2"},{value:"audio3",label:"上游音频 3"},{value:"width",label:"宽度"},{value:"height",label:"高度"},{value:"batch_size",label:"批量数"},{value:"seed",label:"Seed"},{value:"steps",label:"Steps"},{value:"cfg",label:"CFG"},{value:"sampler_name",label:"Sampler"},{value:"scheduler",label:"Scheduler"},{value:"denoise",label:"Denoise"},{value:"model_name",label:"模型名"},{value:"ckpt_name",label:"Checkpoint"},{value:"clip_name",label:"CLIP"},{value:"vae_name",label:"VAE"},{value:"lora_name",label:"LoRA"},{value:"unet_name",label:"UNet"},{value:"control_net_name",label:"ControlNet"},{value:"clip_vision_name",label:"CLIP Vision"},{value:"style_model_name",label:"Style Model"},{value:"upscale_model",label:"放大模型"},{value:"strength_model",label:"LoRA 模型强度"},{value:"strength_clip",label:"LoRA CLIP 强度"},{value:"start_at_step",label:"起始步数"},{value:"end_at_step",label:"结束步数"},{value:"guidance",label:"Guidance"},{value:"shift",label:"Shift"},{value:"fps",label:"FPS"},{value:"frame_rate",label:"帧率"},{value:"num_frames",label:"帧数"},{value:"duration",label:"时长"},{value:"strength",label:"强度"},{value:"weight",label:"权重"},{value:"fixed",label:"固定值"}],ns="t8-basic-text-to-image-sample";function Sn(){return{1:{class_type:"CheckpointLoaderSimple",inputs:{ckpt_name:"请改成你的模型.safetensors"},_meta:{title:"Checkpoint"}},2:{class_type:"CLIPTextEncode",inputs:{text:"a cozy studio, soft light, highly detailed",clip:["1",1]},_meta:{title:"Positive Prompt"}},3:{class_type:"CLIPTextEncode",inputs:{text:"low quality, blurry, bad anatomy",clip:["1",1]},_meta:{title:"Negative Prompt"}},4:{class_type:"EmptyLatentImage",inputs:{width:1024,height:1024,batch_size:1},_meta:{title:"Canvas Size"}},5:{class_type:"KSampler",inputs:{seed:123456,steps:20,cfg:7,sampler_name:"euler",scheduler:"normal",denoise:1,model:["1",0],positive:["2",0],negative:["3",0],latent_image:["4",0]},_meta:{title:"Sampler"}},6:{class_type:"VAEDecode",inputs:{samples:["5",0],vae:["1",2]},_meta:{title:"Decode"}},7:{class_type:"SaveImage",inputs:{filename_prefix:"T8_ComfyUI",images:["6",0]},_meta:{title:"Save Image"}}}}function ss(){return JSON.stringify(Sn(),null,2)}function ye(e){return!e||typeof e!="object"||Array.isArray(e)?[]:Object.entries(e).filter(([,t])=>t&&typeof t=="object"&&!Array.isArray(t)&&t.inputs&&typeof t.inputs=="object")}function jt(e,t){var i;return String(((i=t==null?void 0:t._meta)==null?void 0:i.title)||(t==null?void 0:t.title)||(t==null?void 0:t.class_type)||`#${e}`).trim()}function $e(e){return String((e==null?void 0:e.class_type)||"").trim()}function F(e,t,i,r,o,c){const a=`${i}::${o}`;if(t.has(a))return!1;t.add(a);const f=$e(r),l=jt(i,r),d=It(r,o),k={nodeId:i,fieldName:o,source:c,classType:f,nodeTitle:l,label:`${l} #${i} · ${o}`};return d.length&&(k.options=d),e.push(k),!0}function Pn(e,t){var r;const i=`${((r=e==null?void 0:e._meta)==null?void 0:r.title)||""} ${(e==null?void 0:e.title)||""} ${(e==null?void 0:e.class_type)||""}`.toLowerCase();return/negative|neg|反向|负向|不要|排除/.test(i)?!0:t}function ft(e){if(!Array.isArray(e))return"";const t=e[0];return typeof t=="string"||typeof t=="number"?String(t).trim():""}function kt(e){const t=new Map;for(const[,i]of e){const r=(i==null?void 0:i.inputs)||{},o=ft(r.positive),c=ft(r.negative);o&&t.set(o,"prompt"),c&&t.set(c,"negative")}return t}function W(e,t){return Object.prototype.hasOwnProperty.call(e,t)}function Z(e){return String(e||"").trim().toLowerCase().replace(/[\s-]+/g,"_")}function _t(e){return Array.isArray(e)&&e.length>=1&&e.length<=3&&(typeof e[0]=="string"||typeof e[0]=="number")&&(e.length===1||typeof e[1]=="number"||typeof e[1]=="string")}function qe(e){return!!e&&typeof e=="object"&&!Array.isArray(e)}function zn(e){if(typeof e=="string"){const t=e.trim();return t||null}return typeof e=="number"&&Number.isFinite(e)?e:null}function Ke(e){const t=[],i=new Set;for(const r of e){const o=`${typeof r}:${String(r)}`;i.has(o)||(i.add(o),t.push(r))}return t.slice(0,120)}const Mn={aspect_ratio:["auto","1:1","2:3","3:2","3:4","4:3","9:16","16:9","21:9","9:21","custom"],ratio:["auto","1:1","2:3","3:2","3:4","4:3","9:16","16:9","21:9","9:21"],resolution:["1k","2k","4k"],size:["auto","1k","2k","4k"],quality:["auto","low","medium","high"],background:["auto","transparent","opaque"],output_format:["png","jpg","jpeg","webp"],moderation:["auto","low"],response_format:["url","b64_json"],control_after_generate:["fixed","increment","decrement","randomize"],生成后控制:["fixed","increment","decrement","randomize"]};function Nt(e){if(!qe(e))return e;for(const t of["value","default","selected","current"])if(Object.prototype.hasOwnProperty.call(e,t))return e[t];return e}function Fn(e){const t=Nt(e);return t===null||["string","number","boolean"].includes(typeof t)}function de(e){var t;return`${((t=e==null?void 0:e._meta)==null?void 0:t.title)||""} ${(e==null?void 0:e.title)||""} ${(e==null?void 0:e.class_type)||""}`.toLowerCase()}function D(e,t){if(!qe(e))return;if(Object.prototype.hasOwnProperty.call(e,t))return e[t];const i=Z(t);for(const[r,o]of Object.entries(e))if(Z(r)===i)return o}function ue(e,t=0){if(t>5||e==null)return[];if(Array.isArray(e)){if(_t(e))return[];const i=e.map(zn).filter(o=>o!==null);if(i.length===e.length&&i.length>0)return Ke(i);const r=[];for(const o of e)r.push(...ue(o,t+1));return Ke(r)}if(qe(e)){const i=["options","choices","values","enum","list","items","selectOptions","dropdown"],r=[];for(const o of i)Object.prototype.hasOwnProperty.call(e,o)&&r.push(...ue(e[o],t+1));return Ke(r)}return[]}function It(e,t){var o,c,a,f,l,d,k;const r=[(o=e==null?void 0:e.inputs)==null?void 0:o[t],D(e==null?void 0:e.inputs,`${t}_options`),D(e==null?void 0:e.inputs,`${t}_choices`),D((c=e==null?void 0:e.input_types)==null?void 0:c.required,t),D((a=e==null?void 0:e.input_types)==null?void 0:a.optional,t),D((f=e==null?void 0:e.inputTypes)==null?void 0:f.required,t),D((l=e==null?void 0:e.inputTypes)==null?void 0:l.optional,t),D(e==null?void 0:e.widgets,t),D(e==null?void 0:e.widget,t),D((d=e==null?void 0:e._meta)==null?void 0:d.inputs,t),D((k=e==null?void 0:e._meta)==null?void 0:k.widgets,t),D(e==null?void 0:e.properties,t)];if(Array.isArray(e==null?void 0:e.widgets)){const p=e.widgets.find(m=>Z((m==null?void 0:m.name)||(m==null?void 0:m.field)||(m==null?void 0:m.key))===Z(t));p&&r.push(p)}for(const p of r){const m=ue(p);if(m.length)return m}return Mn[Z(t)]||[]}function Tn(e,t){var f;const i=ue(t==null?void 0:t.options);if(i.length)return i;const r=String((t==null?void 0:t.nodeId)||"").trim(),o=String((t==null?void 0:t.fieldName)||"").trim(),a=(f=ye(e).find(([l])=>l===r))==null?void 0:f[1];return a&&o?It(a,o):[]}function is(e,t){var a,f;const i=String((t==null?void 0:t.nodeId)||"").trim(),r=String((t==null?void 0:t.fieldName)||"").trim(),c=(a=ye(e).find(([l])=>l===i))==null?void 0:a[1];return Nt((f=c==null?void 0:c.inputs)==null?void 0:f[r])}function An(e,t){return/(^|_)(negative|neg|uncond|反向|负向|不要|排除)(_|$)/i.test(e)||/negative|neg|反向|负向|不要|排除/i.test(de(t))}function Ct(e){const t=Z(e);return/^(filename|file_name|filename_prefix|prefix|save_path|output_path|output_dir|folder|subfolder)$/.test(t)}function Rn(e,t){if(Ct(e))return!1;const i=Z(e);if(/^(prompt|positive|positive_prompt|negative|negative_prompt|caption|instruction|description|subject|style|wildcard|conditioning_text)$/.test(i))return!0;const r=/prompt|textencode|caption|wildcard|llm|chat|conditioning|encode|positive|negative/i.test(de(t));return/^(text|string|value)$/.test(i)?r:/(^|_)(prompt|caption|instruction|description)(_|$)/.test(i)?!0:/(^|_)(text|string)(_|$)/.test(i)?r:r&&["text","prompt","value"].includes(i)}function On(e,t){const i=Z(e);return/^(image|img|mask|control_image|reference_image|ref_image|source_image|input_image|init_image|start_image|end_image|face_image|person_image|pose_image|depth_image|normal_image|lineart_image|image_path|mask_image)$/.test(i)||/(^|_)(image|img|mask)(_|$)/.test(i)?!0:/(loadimage|imageinput|mask|controlnet|ipadapter|openpose|depth|lineart|reference)/i.test(de(t))&&["image","img","mask","path","file"].includes(i)}function Kn(e,t){const i=Z(e);return/^(video|video_path|input_video|source_video|reference_video|init_video|frames_video)$/.test(i)||/(^|_)(video|movie|frames)(_|$)/.test(i)?!0:/(loadvideo|videoinput|vhs|video|wanvideo|ltxv|svd|animatediff)/i.test(de(t))&&["video","path","file"].includes(i)}function Zn(e,t){const i=Z(e);return/^(audio|audio_path|input_audio|source_audio|reference_audio|voice|sound|music|speech|wav)$/.test(i)||/(^|_)(audio|voice|sound|music|speech|wav)(_|$)/.test(i)?!0:/(loadaudio|audioinput|audio|tts|stt|voice|sound)/i.test(de(t))&&["audio","path","file","voice"].includes(i)}const Bn=new Set(["width","height","batch_size","seed","steps","cfg","sampler_name","scheduler","denoise","model_name","ckpt_name","clip_name","vae_name","lora_name","unet_name","control_net_name","clip_vision_name","style_model_name","upscale_model","strength_model","strength_clip","start_at_step","end_at_step","guidance","shift","fps","frame_rate","num_frames","duration","strength","weight","control_after_generate","add_noise"]);function Jn(e){const t=Z(e);return t==="noise_seed"?"seed":t==="positive_prompt"?"prompt":t==="negative_prompt"?"negative":Bn.has(t)||/(^|_)(model_name|ckpt_name|clip_name|vae_name|lora_name|unet_name|control_net_name|clip_vision_name|style_model_name|upscale_model)(_|$)/.test(t)?t:""}function Gn(e,t){if(_t(t)||!Fn(t))return!0;const i=Z(e);return Ct(i)?!0:/^(model|clip|vae|positive|negative|latent|latent_image|samples|images|conditioning|control_net)$/.test(i)}function gt(e){const t=String(e||"").toLowerCase();return/(save|preview|output|export).*(image|video|audio|text|string)|(image|video|audio|text|string).*(save|preview|output|export)/.test(t)}function Dn(e){const t=de(e);return/(show\s*anything|showanything|展示任何|展示|viewer|display|inspect|debug|logger|console|watch|note|result)/i.test(t)?!/(prompt|textencode|caption|wildcard|llm|chat|input|loadimage|loadvideo|loadaudio|sampler|generate|generator)/i.test(t):!1}function We(e){const t=[],i=new Set;let r=!1,o=0,c=0,a=0,f=0;const l=[],d=ye(e),k=kt(d);if(!d.length)return l.push("未识别到 API Workflow 节点；请确认导入的是 ComfyUI API 格式，而不是普通前端 workflow。"),{fields:t,imageInputCount:o,videoInputCount:c,audioInputCount:a,outputCount:f,warnings:l};for(const[p,m]of d){const w=$e(m),x=w.toLowerCase(),h=m.inputs||{},E=Object.keys(h),N=Dn(m)||gt(w);if(x.includes("cliptextencode")&&W(h,"text")){const $=k.get(p)||(Pn(m,r)?"negative":"prompt");F(t,i,p,m,"text",$),$==="prompt"&&(r=!0)}if((x.includes("loadimage")||x.includes("imageinput"))&&W(h,"image")&&(o+=1,F(t,i,p,m,"image",`image${o}`)),(x.includes("loadvideo")||x.includes("videoinput")||x.includes("vhs"))&&W(h,"video")&&(c+=1,F(t,i,p,m,"video",`video${c}`)),(x.includes("loadaudio")||x.includes("audioinput"))&&W(h,"audio")&&(a+=1,F(t,i,p,m,"audio",`audio${a}`)),(x.includes("emptylatent")||x.includes("latentimage"))&&(W(h,"width")&&F(t,i,p,m,"width","width"),W(h,"height")&&F(t,i,p,m,"height","height"),W(h,"batch_size")&&F(t,i,p,m,"batch_size","batch_size")),x.includes("ksampler")||x.includes("sampler")){for(const y of["seed","noise_seed"])W(h,y)&&F(t,i,p,m,y,"seed");for(const y of["steps","cfg","sampler_name","scheduler","denoise"])W(h,y)&&F(t,i,p,m,y,y)}for(const y of["model_name","ckpt_name","clip_name","vae_name","lora_name","unet_name","control_net_name","clip_vision_name","style_model_name","upscale_model","strength_model","strength_clip"])W(h,y)&&F(t,i,p,m,y,y);for(const y of E){if(N||i.has(`${p}::${y}`)||Gn(y,h[y]))continue;const $=Jn(y);if($){F(t,i,p,m,y,$);continue}if(Rn(y,m)){const S=An(y,m)?"negative":"prompt";F(t,i,p,m,y,S),S==="prompt"&&(r=!0);continue}if(On(y,m)){o+=1,F(t,i,p,m,y,`image${o}`);continue}if(Kn(y,m)){c+=1,F(t,i,p,m,y,`video${c}`);continue}if(Zn(y,m)){a+=1,F(t,i,p,m,y,`audio${a}`);continue}F(t,i,p,m,y,Z(y))}gt(w)&&(f+=1),!x&&E.length>0&&l.push(`#${p} 缺少 class_type，可能不是标准 API Workflow 节点。`)}return t.some(p=>p.source==="prompt")||l.push("未自动找到正向 Prompt 字段；可以在映射表中手动添加或切到高级 fields JSON。"),o>0&&!t.some(p=>/^image\d+$/.test(String(p.source||"")))&&l.push("检测到图像输入节点，但没有生成图片映射。"),{fields:t,imageInputCount:o,videoInputCount:c,audioInputCount:a,outputCount:f,warnings:l}}function rs(e,t=We(e)){const i=!!e&&typeof e=="object"&&!Array.isArray(e),r=Array.isArray(t.fields)?t.fields:[],o=r.some(d=>d.source==="prompt"||d.source==="positive"),c=r.some(d=>d.source==="negative"),a=r.some(d=>["ckpt_name","model_name","clip_name","vae_name","lora_name"].includes(String(d.source||""))),f=r.some(d=>d.source==="width")&&r.some(d=>d.source==="height"),l=[];return l.push({id:"api-format",level:i&&r.length?"ok":"warn",label:i&&r.length?"API Workflow 已识别":"还没有识别到 API Workflow",detail:i?"节点需要包含 class_type 和 inputs；如果字段为 0，通常导入的是普通前端 workflow。":"请从 ComfyUI 右上角设置开启 dev mode，再导出 API Workflow JSON。"}),l.push({id:"prompt",level:o?"ok":"warn",label:o?"正向 Prompt 可编辑":"未找到正向 Prompt",detail:o?"运行时会把节点提示词写入该字段。":"可在参数映射里手动把 CLIPTextEncode.text 设置为正向 Prompt。"}),l.push({id:"negative",level:c?"ok":"info",label:c?"负向 Prompt 已识别":"未识别负向 Prompt",detail:c?"采样器连接可帮助区分正向/负向。":"没有负向也可以运行；需要时手动映射另一个 CLIPTextEncode.text。"}),l.push({id:"size",level:f?"ok":"info",label:f?"尺寸字段可编辑":"尺寸可能固定在 workflow 内",detail:f?"宽高会跟随节点尺寸/参数写入。":"如果 workflow 用固定 latent 或外部尺寸节点，请确认输出比例符合预期。"}),l.push({id:"model",level:a?"info":"ok",label:a?"模型字段建议检查":"未暴露模型字段",detail:a?"Checkpoint、LoRA、VAE、CLIP 名必须和本机 ComfyUI 模型文件名一致。":"模型名会按 workflow 内固定值运行。"}),l.push({id:"output",level:t.outputCount>0?"ok":"warn",label:t.outputCount>0?`输出节点 ${t.outputCount} 个`:"未找到输出节点",detail:t.outputCount>0?"SaveImage / PreviewImage 等输出会被 T8 自动归一化。":"请确认 workflow 最后有 SaveImage、PreviewImage、SaveVideo 或 SaveAudio。"}),l}function Ze(e){const t=[],i=new Set;for(const r of Array.isArray(e)?e:[]){const o=String((r==null?void 0:r.nodeId)||"").trim(),c=String((r==null?void 0:r.fieldName)||"").trim();if(!o||!c)continue;const a=`${o}::${c}`;if(i.has(a))continue;i.add(a);const f=Object.prototype.hasOwnProperty.call(r,"value"),d=String(r.source||"").trim()||(f?"fixed":c),k={nodeId:o,fieldName:c,source:d};d==="fixed"&&f&&(k.value=r.value);const p=ue(r.options);p.length&&(k.options=p),t.push(k)}return t}function Un(e,t){return $e(e).toLowerCase().includes("cliptextencode")&&t==="text"}function Hn(e,t){return["prompt","positive","negative","text"].includes(e)||e===t}function xt(e){return`${e.nodeId}::${e.fieldName}`}function Ee(e){const t=Array.isArray(e)?e:String(e||"").split(/[\n,;，；]+/),i=[];for(const r of t){const o=String(r||"").trim();!o||i.includes(o)||i.push(o.slice(0,120))}return i.slice(0,200)}function we(e){if(typeof e=="string"){const t=e.trim();if(!t)return[];if(t.startsWith("{")&&t.endsWith("}")||t.startsWith("[")&&t.endsWith("]"))try{return we(JSON.parse(t))}catch{return t}return t}if(Array.isArray(e))return e;if(e&&typeof e=="object"){const t=e,i=["rules","excludeRules","fieldExcludeRules","comfyExcludeRules","comfyFieldExcludeRules","autoMappingExcludeRules","text"];for(const r of i)if(t[r]!==void 0&&t[r]!==null)return we(t[r]);if(t.payload!==void 0&&t.payload!==null)return we(t.payload);if(t.data!==void 0&&t.data!==null)return we(t.data)}return e}function os(e,t="comfyui"){return{schema:Ln,version:1,exportedAt:new Date().toISOString(),source:t,rules:Ee(e)}}function as(e){return Ee(we(e))}function z(e){return String(e||"").trim().toLowerCase()}function Be(e,t){return!!t&&!!e&&e.includes(t)}function Wn(e,t,i){const r=Ee(i);if(!r.length||!t)return!1;const o=ye(e),c=new Map(o),a=String(t.nodeId||"").trim(),f=String(t.fieldName||"").trim(),l=String(t.source||f||"").trim(),d=c.get(a),k=String(t.classType||$e(d)||"").trim(),p=String(t.nodeTitle||(d?jt(a,d):"")).trim(),m=String(t.label||`${p} #${a} · ${f}`).trim(),w=new Set([z(l),z(f),z(a),z(`#${a}`),z(`${a}.${f}`),z(`#${a}.${f}`),z(`${k}.${f}`),z(`${k}.${l}`),z(p),z(k)].filter(Boolean)),x=z([a,`#${a}`,f,l,k,p,m,`${a}.${f}`,`#${a}.${f}`,`${k}.${f}`,`${k}.${l}`].filter(Boolean).join(" "));for(const h of r){const E=z(h);if(!E)continue;const N=E.match(/^(source|field|class|node|title)\s*:\s*(.+)$/);if(N){const[,y,$]=N,S=z($);if(!S)continue;if(y==="source"&&z(l)===S||y==="field"&&z(f)===S||y==="class"&&Be(z(k),S)||y==="node"&&(z(a)===S||z(`#${a}`)===S)||y==="title"&&Be(z(p),S))return!0;continue}if(w.has(E)||Be(x,E))return!0}return!1}function ls(e,t,i){const r=Ee(i),o=Array.isArray(t)?t:[];return r.length?o.filter(c=>!Wn(e,c,r)):o.slice()}function cs(e,t,i={}){const r=ye(e),o=new Map(r),c=kt(r),a=[],f=new Set;let l=!1;const d=Ze(t),k=d.length?d:Ze(We(e).fields);let p=!1;for(const w of k){const x={...w},h=o.get(x.nodeId),E=h?Tn(e,x):ue(x.options);E.length&&(x.options=E);const N=String(x.source||x.fieldName||"").trim(),y=c.get(x.nodeId);h&&y&&Un(h,x.fieldName)&&Hn(N,x.fieldName)&&(x.source=y==="prompt"?"prompt":"negative",y==="negative"&&["prompt","positive","text"].includes(N)&&(p=!0));const $=xt(x);f.has($)||(f.add($),(x.source==="prompt"||x.source==="positive")&&(l=!0),a.push(x))}if((i.addMissingPromptField===!0||i.addMissingPromptField!==!1&&(!d.length||p))&&r.length&&!l){const w=We(e).fields.find(x=>(x.source==="prompt"||x.source==="positive")&&!f.has(xt(x)));w&&a.push(Ze([w])[0])}return a}const us=()=>null,ds=()=>null,Ve={"interactive-game-script":`# 互动游戏脚本

> 将游戏需求转成 4–8 个大屏触控 UI 界面、声明式互动逻辑和可演示的图片热点原型。

1. 左侧黄色端口连接游戏需求，蓝色端口可连接角色、品牌、场景或 UI 风格参考图。
2. 选择界面状态图、线性步骤流或剧情分支树，再选择适合展厅触摸屏的 UI 设计风格，并用独立 LLM 生成可编辑脚本。
3. 逐界面生成 16:9 效果图；失败界面可单独重试，全部完成后自动拼接概览宫格。
4. 原型模式可在界面图上框选热点并预览点击、滑动、条件、状态和跳转。
5. 右侧蓝色端口输出独立界面图，黄色端口按界面输出脚本文本；节点内可导出 PPTX/PDF/DOCX/原型 ZIP。`,"storyboard-grid":`# 分镜脚本

> 把上游文本大纲写成指定数量的完整分镜卡，一次生成宫格整图并自动拆分为单镜头文件。

## 使用流程
1. 把文本节点或文本素材集连接到左侧文本端口。
2. 设置行数、列数、LLM 独立配置和生图模型。
3. 点击“生成脚本”检查并编辑镜头卡，或点击“一键生成”连续完成脚本、生图和拆分。
4. 右侧蓝色端口输出拆分镜头合集，黄色端口按镜头输出脚本文本。

## 输出规则
- 整张宫格图只在节点内预览和下载，不会混入下游。
- 镜头固定按从左到右、从上到下排序。
- 修改大纲或行列数后，现有脚本会标记为过期，必须重新生成脚本。
- 生图成功但拆分失败时，可使用整图旁的剪刀按钮重新拆分。
`,"prompt-reverse":`# 提示词反推

> 使用「LLM 独立配置」中的视觉模型识别图片，输出可直接用于 GPT Image 2 的自然语言提示词。

## 快速开始
1. 从上传素材、输出素材、图像节点或图像素材集连接图片到左侧蓝色端口；也可以点击节点内的上传区域选择本地图片。
2. 需要替换画面内容时，把文本节点连接到左侧黄色「内容文本」端口。
3. 在「识图 LLM」中选择一个支持图片输入的 LLM 独立配置，并设置细节强度、输出语言及补充要求。
4. 点击「反推 GPT Image 2 提示词」；也可开启「换内容」开关，让一次运行自动完成反推与内容替换。

## 标题栏与端口
- **右上角问号图标**：打开当前帮助文档。按钮与其它节点使用相同的帮助组件，不会触发节点拖动。
- **左侧蓝色端口（输入图像）**：接收单张图、多个图像节点或图像素材集。没有图片时运行按钮不可用。
- **左侧黄色端口（内容文本）**：接收文本节点或文本素材集，作为换内容时的新主体、场景、叙事、图案和画面文字来源。
- **右侧黄色端口（输出文本）**：输出当前结果框中的最终提示词。结果被手动修改后，下游会读取修改后的版本。

## 识图素材区
- **连接上游图片**：连接后会自动显示缩略图；上游图片发生变化时，节点中的素材也会同步更新。
- **点击上传 / 加号按钮**：从本机添加图片。支持一次选择多张，节点最多使用前 10 张。
- **图 1 为主体**：单图时直接反推该图；多图时把第 1 张当作主要画面，其余图片作为主体、风格、材质或构图补充，合成一条多参考图提示词。
- **拖动缩略图排序**：改变模型接收图片的先后顺序。需要更换主体图时，把目标图片拖到第 1 位。
- **删除本地图片**：本地上传缩略图上的删除按钮只移除当前节点中的临时图片，不删除磁盘原文件。上游图片应通过断开连线或修改来源节点移除。

## 内容文本与换内容
- **内容文本状态**：显示是否已从左侧黄色端口接入文本；接入后会显示文本段数及内容预览。
- **结果区「换内容」按钮**：当前反推结果和内容文本都存在时可用。节点会保留原提示词的媒介、风格、构图、镜头、光色、材质与渲染质感，同时把主体、物体、动作、叙事、场景、道具、图案、招牌和其它可见文字替换为内容文本所阐述的内容。
- **「换内容」开关**：开启后，主运行按钮变为「反推并换内容」。一次点击会先从图片得到完整反推提示词，再自动用接入文本替换其中的语义内容，最终只向下游发布融合后的提示词。
- 内容文本中明确给出的主标题、副标题、章节标题、正文、署名、日期和标签会按语义层级逐字保留；没有显式文案时，模型会从输入原文提炼明确标题和关键句，不使用“文字不可辨识”“无需清晰可读”或占位文字等弱化描述，也不添加原文之外的事实或口号。

## 识图 LLM（来自独立配置）
- 下拉列表只读取「API 设置 → LLM 独立配置」中的配置，显示配置名称及其固定模型名。
- API Key 只保存在后端设置中；画布节点仅保存配置 ID 和模型名，不保存明文密钥。
- 必须选择支持视觉/图片输入的模型。纯文本模型无法读取图片，通常会返回“不支持 image_url”或类似错误。
- 切换配置只影响后续运行，不会自动覆盖已经生成的结果。

## 细节强度
- **简洁**：约 80–160 个中文字或 60–100 个英文词。只保留创作意图、主体、构图、场景和核心风格，适合快速试图或后续自行扩写。
- **标准**：约 220–420 个中文字或 140–240 个英文词。均衡描述主体、镜头、环境、光色、材质和氛围，是默认档，适合大多数 GPT Image 2 生图任务。
- **详细**：约 500–800 个中文字或 300–480 个英文词。增加前中后景、空间层次、材质表现、光线方向、成像方式和微观细节，适合复现复杂画面。
- **极致**：约 900–1400 个中文字或 550–850 个英文词。尽量覆盖全部可见元素及其位置和视觉关系，适合展陈空间、复杂产品、多人场景等高信息量图片，但生成和阅读耗时更高。
- 档位下方的灰色说明会显示当前档位的侧重点及建议长度。细节强度控制输出密度，不改变输入图片分辨率。

## 输出语言
- **简体中文**：输出自然、准确的中文提示词；图片中必须保留的外文会使用原文并加引号。
- **English**：整条提示词使用英文，适合需要英文工作流或继续交给英文提示词模板处理的情况。
- 语言选项只控制最终提示词，不会翻译或修改输入图片本身。

## 补充要求
- 这是可选输入，用于告诉识图模型本次反推的重点，例如「保留清晰可见的招牌文字」「强调低机位镜头」「只提取产品造型，忽略水印」。
- 补充要求会和固定的 GPT Image 2 反推规范一起发送，不会直接拼接到最终结果末尾。
- 建议写目标和取舍，不要在这里粘贴 API 参数、JSON 或 Midjourney 指令；节点会要求模型输出 GPT Image 2 易理解的自然语言。
- 可使用输入框的扩大编辑功能处理较长说明。

## 运行按钮
- **反推 GPT Image 2 提示词**：使用当前图片顺序、LLM 配置、细节强度、语言和补充要求发起一次非流式识图请求。
- **反推并换内容**：仅在「换内容」开关开启且已接入内容文本时可用；运行中会依次显示识图和换内容状态。
- 运行期间按钮会显示正在使用的模型并暂时锁定相关控件，避免同一节点重复提交。
- 节点支持画布批量运行和循环调度；成功后会按全局设置播放任务完成提示音。
- 再次运行会用新结果替换当前结果；如果请求失败，已有结果数据不会被密钥或错误信息污染。

## 反推结果区
- **结果文本框**：显示模型返回的最终提示词，可以直接手动修改。修改会同步写入标准的 \`prompt\`、\`outputText\` 和 \`text\` 字段。
- **复制**：把当前完整提示词复制到系统剪贴板。
- **换内容**：用当前接入的内容文本改写结果；如果改写失败，原结果会保留，可检查配置或文本后重试。
- **清空图标**：清空结果和错误状态，保留图片、模型、强度、语言及补充要求，方便重新运行。
- **扩大编辑**：在更大的编辑器中检查和修改长提示词。
- **提示词模板入口**：结果按图像提示词类型接入全局模板库，可继续收藏或复用。

## 输出规则
- 输出按「主体 → 构图与镜头 → 场景空间 → 光线色彩 → 材质氛围 → 媒介质感 → 关键细节」组织为一条可直接使用的自然语言提示词。
- 不输出 Midjourney 参数、Stable Diffusion 权重、负面提示词列表、JSON、Markdown 标题、代码块或解释文字。
- 只描述图片中可见或能够合理确定的信息。无法辨认的文字只描述其排版作用，不编造具体内容。

## 推荐工作流
- **单图复现**：上传素材 → 提示词反推 → 图像（选择 GPT Image 2）。使用「标准」或「详细」。
- **多参考图融合**：把主构图图排在第 1 位，风格图、材质图和主体参考图排在后面，再连接 GPT Image 2 图像节点。
- **人工精修**：先用「详细」生成，在结果框中删掉不需要的元素并补充必须保留的文字、比例或空间约束，再送入下游。

## 常见问题
- **运行按钮不可点击**：尚未连接或上传图片；如果已开启「换内容」，还必须连接内容文本。
- **换内容按钮不可点击**：反推结果为空、内容文本未连接，或节点正在运行。
- **模型提示不支持图片**：当前 LLM 配置对应纯文本模型，请换成支持多模态视觉输入的模型。
- **提示未配置 API Key / 鉴权失败**：到 API 设置检查所选 LLM 独立配置的 Base URL、API Key 和模型名。
- **多图结果偏离主图**：把真正的主图拖到第 1 位，并在补充要求中明确其它图片分别只提供什么参考。
- **图片文字被编造**：在补充要求中写明「仅保留清晰可辨文字，不可辨内容不要猜测」；节点的固定规则也会默认执行这一约束。
- **结果太短或太长**：调整细节强度后重新运行；只想微调措辞时可直接编辑结果，不必再次消耗模型调用。
`,"fhl-image-gen":`# FHL 生图

> 通过 FHL Images API 调用固定模型 gpt-image-2，支持文生图、组合参考图编辑、批量提示词、逐图编辑和可恢复的工作流批改。

## 使用前准备
1. 打开「API 设置 → FHL Images」，新增至少一个 worker，填写名称和 API Key，并保持启用。
2. 节点标题栏会显示 worker 已启用数 / 总数。已启用数为 0 时「运行」按钮不可用。
3. 多个 worker 可以并行处理独立任务；每个 worker 同一时间只执行一个任务。密钥只保存在后端本地设置中，不写入画布。

## 标题栏
- **FHL 生图**：节点名称。
- **Images API · gpt-image-2**：表示节点固定使用 FHL Images API 和 gpt-image-2，不会切换到 Responses API 或其它模型。
- **worker A/B**：A 是当前启用的 worker 数，B 是已配置的 worker 总数。
- **右上角问号图标**：打开本帮助文档；不会触发节点拖动。
- **旋转加载图标**：表示任务正在创建、轮询或执行。

## 左侧输入端口
- **text**：文本输入。快速和逐图编辑模式下，节点内提示词留空时自动使用上游文本；批量提示词模式下，上游文本优先于节点内多行提示词，最多取前 20 条。
- **fixed**：固定参考图。快速模式接入 fixed 后会由文生图自动切换为组合参考图编辑；工作流模式中，fixed 会按原顺序放在每个变量图片之前。
- **items**：变量图片素材集。逐图编辑时每张图片是一个独立任务；工作流模式下每张变量图片会与 fixed 和所有场景模板组合。
- 同一图片地址会自动去重。上游连线素材与节点内本地上传素材会合并。

## 右侧输出端口
- **image**：输出全部成功图片。第一张同时写入主图片字段，方便连接图像、输出素材或其它图片处理节点。
- **text**：输出任务摘要，包括状态、成功数、失败数等信息。
- 成功产物会进入现有生成历史、下游素材聚合和任务完成提示音流程。

## 顶部四种模式

### 快速
- 没有 fixed 图片时为文生图；输入一条提示词后生成图片。
- 接入或上传 fixed 图片后自动变为组合参考图编辑，提示词用于说明需要保留、替换或修改的内容。
- 文生图可在「同提示词 1–9」和「连续 1–50」之间切换。
- 组合编辑使用「变体」数量，范围为 1–4；每个变体使用相同提示词和相同参考图顺序。
- 普通组合编辑最多 10 张参考图。1–5 张是常规范围；6–10 张会显示实验性警告；2 张及以上强制串行，避免同一组参考图并发造成顺序或负载问题。

### 批量提示词
- 节点内输入框每一非空行是一条独立提示词，最多 20 条。
- 如果连接了 text 上游，则优先使用上游文本，节点内多行内容暂不参与本次任务。
- 每条提示词独立生成一张图片，可以分发给不同 worker。
- 右侧「任务数」只显示当前解析出的有效提示词数量，不能手动修改。

### 逐图编辑
- 在 items 中接入或上传 1–10 张变量图片，并输入一条统一编辑提示词。
- 每张 items 图片单独执行一次编辑，彼此之间不组合，可并行分发到不同 worker。
- 此模式不会把 fixed 图片加入每个逐图任务；需要固定参考图参与每个变量项时，请使用「工作流」。
- 右侧「任务数」显示实际将处理的 items 数量，最多 10。

### 工作流
- 用于「固定参考图 + 多张变量图片 + 多个场景模板」的批量组合编辑。
- fixed 是每个任务都复用的固定上下文；items 是逐项变化的素材；每个 item 会依次套用全部模板。
- 同一 item 的模板任务会粘性分配给同一 worker，并避免同一 item 的模板同时执行。
- 默认最多处理前 100 个 item；失败或缺失结果会按「修复轮数」串行补跑，默认 2 轮。
- 已经存在且可正常读取的结果会复用；停止、应用重启或任务中断后可以点击「恢复」。

## 提示词与模板输入框
- **FHL 提示词**：快速模式和逐图编辑模式使用。写清主体、构图、参考图关系、保留项、修改项和禁止项。
- **FHL 批量提示词**：批量提示词模式使用，一行一个任务；空行会被忽略，重复行会去重。
- **工作流场景模板**：通用工作流使用。多个模板之间用单独一行的三个短横线分隔。每段模板会成为一个场景任务。
- 提示词输入框支持项目统一的扩大编辑能力，适合编辑较长说明。

## 工作流预设
- **通用模板**：使用用户填写的场景模板，不预设商品类别或画面结构。
- **nail-tryon 美甲试戴**：内置四个美甲商品试戴场景模板，包括双手特写、面部与手部近景、半身展示和全身场景。
- nail-tryon 要求且只允许 1 张 fixed 人物图，items 提供美甲产品图；选择后比例固定为 9:16，不能手动更改。
- 预设会自动构建人物一致性、穿搭保持、商品特征映射和安全展示要求，节点内模板框会隐藏。

## fixed 与 items 素材框
- **上传图标**：从本机选择一张或多张图片，上传后保存在当前节点配置中。
- **缩略图**：最多显示前 6 张预览；计数显示合并上游和本地上传后的实际数量。
- **清空本地**：只移除当前节点直接上传的图片，不会删除磁盘文件，也不会移除上游连线传入的图片。
- fixed 最多使用 10 张。工作流中 fixed 加当前 item 合计也不能超过 10 张。
- 要移除上游素材，请断开对应连线或修改上游节点。

## 规格
- **2K**：默认选项，速度和成本更适合日常生成。
- **4K**：只有用户显式选择时才会提交 4K；任务不会因提示词出现“4K”而自动切换。
- 节点只允许经过实测的固定尺寸矩阵，不能输入任意宽高。

## 比例
- **2K 文生图**：1:1、3:2、2:3、4:3、3:4、16:9、9:16、2:1、1:2、7:4、4:7。
- **2K 编辑**：在文生图比例基础上额外支持 5:4、4:5、3:1、1:3。
- **4K**：1:1、3:2、2:3、16:9、9:16、2:1、1:2、3:1、1:3、7:4、4:7。
- 切换规格或文生图 / 编辑状态后，如果旧比例不受支持，节点会自动回退到当前列表中的第一个有效比例。
- 请求会在提示词末尾附加严格画幅说明，减少模型返回错误方向或错误比例的情况。

## 保存格式
- **JPG**：默认格式。使用质量 100、4:4:4 色度和高质量 JPEG 编码，适合预览、传递和节省空间；最终目录只落盘 JPG。
- **PNG**：无损保存上游返回的原始 PNG，适合透明、后期或需要逐像素保真的场景。
- FHL 上游始终返回 PNG。选择 JPG 时会在系统临时目录完成中间转码并随即清理，服务器、网盘及 output/fhl 任务目录不会再出现额外 PNG。
- JPEG 编码本质上不是数学无损；需要严格无损时请选择 PNG。

## 并发
- 可设置 1–10，实际并发取「设置值、任务数、启用 worker 数、10」中的最小值。
- 单个任务只占用一个 worker；同一 worker 同时只运行一个任务。
- 快速组合编辑含 2 张及以上 fixed 时会强制并发为 1；逐图编辑和工作流中的独立 item 可使用多个 worker。
- 429、502、503、504、524、限流或账号池繁忙等临时错误最多重试 3 次。多 worker 时故障 worker 冷却 60 秒；单 worker 时等待 15 秒。
- 鉴权失败只会在当前任务轮次禁用对应 worker，不会删除设置中的 worker。

## 数量控件
- **张数**：快速文生图「同提示词」模式生成 1–9 张。
- **连续**：快速文生图「连续」模式重复运行 1–50 次，适合持续探索不同结果。
- **变体**：快速组合编辑生成 1–4 个编辑变体。
- **任务数**：批量提示词和逐图编辑模式的只读统计值。
- **修复轮数**：工作流主队列结束后，对缺失或失败结果执行的串行补跑轮数，范围 0–5；设为 0 表示不自动修复。

## 快速模式数量切换
- **同提示词 1–9**：适合一次请求少量变体，数量由「张数」控制。
- **连续 1–50**：适合长时间连续探索，次数由「连续」控制。
- 接入 fixed 转为编辑后，这两个切换项会隐藏，改用「变体」。

## 工作流附加控件
- **处理上限**：只处理 items 的前 N 项。默认按输入数量计算，并以 100 为常用上限；可降低数值先小批量验证。
- **仅预检，不调用 FHL**：创建并展开任务、生成清单和统计，但不请求 FHL API。适合检查 fixed、items、模板数量和预计任务规模。

## 运行、停止与恢复
- **运行**：校验当前模式必需输入，创建持久化任务并开始轮询。当前界面没有启用 worker 时按钮不可用，包括仅预检模式；请先启用至少一个 worker。
- **停止**：中止当前任务。已成功文件保留，未完成项会标记为取消或等待恢复。
- **恢复**：在 partial、failed、cancelled 或 interrupted 状态出现。恢复时先校验已有文件，只补跑缺失或损坏任务。
- 应用重启后，原本 running 或 queued 的任务会变为 interrupted，不会静默丢失。

## 状态与任务队列
- 顶部状态行显示任务状态、成功数 / 总数和完成百分比。
- 进度条按成功、失败、取消等终态任务数量计算。
- 最近任务列表显示状态、模板名称或任务 ID、worker 名称和尝试次数。
- **success** 表示产物已保存且可读取；**failed** 表示重试后仍失败；**cancelled** 表示被停止；**partial** 表示部分成功；**completed** 表示全部完成。
- 错误区域会显示请求、鉴权、比例、素材或上游服务错误。可先修正配置，再使用恢复或重新运行。

## 下载文件
- **manifest.json**：完整任务请求摘要、任务结果、worker 统计和产物地址。
- **summary.csv**：适合表格查看的逐任务状态、worker、尝试次数、尺寸、地址和错误。
- **failures.json**：只包含失败和取消任务，方便定位需要重跑的项目。
- **sessions.json**：记录主运行、恢复和修复轮次的会话统计。
- 图片产物保存在 output/fhl/任务ID 目录，并通过应用本地文件地址提供给画布和下载入口。

## 推荐用法
- **单条文生图**：快速 → 不接 fixed → 输入提示词 → 2K / 合适比例 → JPG → 张数 1 → 运行。
- **组合参考编辑**：快速 → fixed 放主体图、风格图或商品图 → 在提示词中说明每张图的作用 → 变体 1–4 → 运行。
- **多提示词批量**：批量提示词 → 每行一条提示词 → 并发不超过启用 worker 数 → 先用 2K 验证。
- **逐图统一修改**：逐图编辑 → items 放待修改图片 → 写统一修改要求 → 任务数确认无误 → 运行。
- **固定人物批量试戴**：工作流 → nail-tryon → fixed 放 1 张人物图 → items 放产品图 → 先勾选预检确认任务规模 → 取消预检后运行。

## 常见问题
- **运行按钮不可用**：没有启用的 FHL worker。到 API 设置新增或启用 worker。
- **提示词为空**：快速或逐图编辑没有节点提示词，也没有 text 上游；填写提示词或连接文本节点。
- **批量任务数为 0**：没有有效上游文本，节点内也没有非空提示词行。
- **工作流无法运行**：缺少 fixed、items 或通用模板；nail-tryon 还要求 fixed 恰好 1 张。
- **比例自动变化**：切换规格或接入 fixed 后，原比例不在新模式支持矩阵内，节点自动选择有效比例。
- **多参考图很慢**：2 张以上组合参考图为保证顺序和稳定性会强制串行。
- **部分任务失败**：检查失败分类和 worker 错误；临时错误通常已自动重试，可点击恢复补跑缺失项。
- **切换格式后旧任务目录仍有另一种格式**：格式选择只影响新任务；旧任务的历史文件不会自动删除。请新建任务验证，或手动清理旧任务目录。
- **本地清空后图片仍存在**：图片来自上游连线，请断开连线或修改上游素材。
`,"import-cam-project":`# 导入项目白模

> 列出本机 cam-output 项目目录，并将选中项目 camoutput 文件夹内的图像导入为图像素材集

## 用途
用于从本机已有的 CAM 项目（如 SketchUp / 3D 软件导出的白模渲染序列）批量导入图像，作为后续展陈生图节点的参考素材。

## 主要控件
- **展馆类型**：默认科技馆，可选择 20 种常规展馆类型，控制环境氛围和空档填充内容
- **展厅主体**：可手动输入主题；留空时根据全部接入展项自动归纳
- **项目目录**：默认读取 \`C:\\\\cam-output\`，可在配置中修改。列出该目录下所有子文件夹作为可选项目
- **项目列表**：点击刷新按钮重新扫描；选中一个项目后展开 camoutput 子目录
- **导入按钮**：把选中项目 camoutput 文件夹内的所有图像（png/jpg/webp）打包成图像素材集，输出到下游
- **筛选**：可按文件名前缀或后缀过滤

## 输出
- 图像素材集端口：所有匹配的图像，按文件名排序

## 注意
- 仅支持本机路径，不能填写网络地址
- 若目录无图像，输出为空素材集
`,"elevation-prompt":`# 立面提示词

> 解析 DOCX / 文本 PDF / TXT，AI 提炼内容并生成彩立面概念 Prompt 与准确图文工艺排版清单

## 用途
读取展陈资料文档（展陈大纲、空间说明、工艺要求等），用 LLM 提炼每个立面的内容，输出可用于下游展陈图生图的提示词，并生成图文工艺排版清单。

## 输入接口
- **文档**：DOCX / PDF / TXT 文件，建议小于 100MB
- **文本**：可选的补充文本素材（接入后会与文档内容合并提炼）

## 主要控件
- **LLM 模型**：用于内容提炼的语言模型
- **立面数量**：预期生成的立面数量
- **风格关键词**：可选，附加到每个立面提示词末尾
- **工艺清单开关**：开启后额外生成图文工艺排版清单（含工艺类型、尺寸、材质等）

## 输出
- 文本端口：每个立面一段提示词（多段文本素材集）
- 文本端口：图文工艺排版清单（开关开启时）
`,"exhibition-img2img":`# 展陈图生图

> 结构示意图 / 表现效果图 / 工艺版式

## 用途
双参考图展陈图生图：基于结构示意图 + 空间表现效果图生成最终展陈效果图，支持工艺版式与优先级控制。是展陈工作流的核心生图节点。

## 输入接口
- **平面布局图**：与空间结构示意图互斥；添加相机后决定渲染视角
- **空间结构示意图**：保留结构、动线、分区；标注仅作理解参考
- **色彩与材质参考图**：仅提取色彩、材质、肌理、光泽和灯光氛围
- **展品参考图**：可多张，连接展品外观与主题参考图
- **展墙内容文本**：接入后自动启用展墙内容设计

## 主要控件
- **图像数量**：1~4 张，每次生成多张候选
- **优先级排序**：参考图优先级（结构 > 色材 > 展品）
- **工艺版式**：装饰 / 多媒体 / 艺术品 / 展陈 / 展柜 / 展台 / 顶部 / 其它
- **图像尺寸**：1K / 2K / 4K
- **模型选择**：图像生成模型（GPT Image 2 / Nano Banana Pro 等）
- **种子**：可锁定复现

## 输出
- 图像端口：展陈图生图结果
- 文本端口：最终提示词文本（便于调试与复用）
`,"exhibition-style-transfer":`# 风格迁移

> 展陈空间风格迁移：原始图像结构不变，仅迁移设计风格、色彩、材质与表面质感

## 用途
当原始展陈效果图结构合理但风格不符合预期时，使用此节点保留原图结构（墙体、展位、动线），仅迁移设计风格、色彩、材质与表面质感。

## 输入接口
- **原始图像**：需保留结构的展陈效果图
- **风格参考图**：期望迁移的目标风格（色彩 / 材质 / 质感）
- **文本提示词**：可选，补充风格描述

## 主要控件
- **风格强度**：0~1，控制风格迁移程度
- **结构保留度**：0~1，控制原图结构的保留程度
- **图像尺寸**：1K / 2K / 4K
- **模型选择**：图像生成模型
- **种子**：可锁定复现

## 输出
- 图像端口：风格迁移后的展陈效果图
`,"exhibition-recolor":`# 主色调更换

> 展陈空间主色调更换：输入原始图像，使用主色、辅助色、点缀色和明暗度进行语义换色，并保护指定展品对象

## 用途
保留原图结构、材质、光影，仅替换展陈空间的色彩方案。支持保护指定展品对象（不参与换色）。

## 输入接口
- **原始图像**：需要换色的展陈效果图
- **保护对象参考图**：可选，标记不参与换色的展品区域

## 主要控件
- **主色**：空间主色调（hex 或色名）
- **辅助色**：次要色彩
- **点缀色**：小面积点缀色
- **明暗度**：-1~1，整体明暗调整
- **保护展品**：开关，开启后保护对象参考图中的区域不换色
- **模型选择**：图像生成模型

## 输出
- 图像端口：换色后的展陈效果图
`,"exhibition-lighting-heatmap":`# 灯光热力图

> 展陈空间灯光热力分析：输入图像后生成覆盖层或独立伪彩色光照热力图，支持模型、尺寸和格式选择

## 用途
分析展陈空间的光照分布，生成热力图用于评估照明均匀性、重点照明位置、暗区分布等。

## 输入接口
- **原始图像**：需要分析的展陈效果图

## 主要控件
- **输出模式**：覆盖层（叠加在原图上）/ 独立热力图（仅伪彩色）
- **色带**：热力图配色方案（jet / viridis / inferno 等）
- **图像尺寸**：1K / 2K / 4K
- **格式**：PNG / JPEG / WebP
- **模型选择**：分析模型

## 输出
- 图像端口：灯光热力图（覆盖层或独立图）
`,"exhibition-creative-image":`# 展陈创意生图

> 面向序厅、尾厅和重亮点展项空间：单空间图约束建筑空间，LLM 创意描述后多次图生图

## 用途
用于需要创意发挥的展陈空间（序厅、尾厅、重亮点展项）。先用单张空间图约束建筑结构，再用 LLM 生成创意描述，最后多次图生图迭代。

## 输入接口
- **空间约束图**：建筑空间结构图（墙体 / 高度 / 入口位置）
- **主题文本**：展项主题、故事线、情感基调

## 主要控件
- **LLM 模型**：用于生成创意描述
- **提示词创作约束**：可多选或不选；所选管理员预设会在每次调用 LLM 创作创意描述时同时生效
- **图像模型**：用于图生图
- **迭代次数**：1~5，多次图生图逐步细化
- **创意强度**：LLM 创意发挥程度
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：最终创意展陈效果图（多次迭代后的最优结果）
- 文本端口：LLM 生成的创意描述
`,"exhibition-render-to-elevation":`# 效果图转立面

> 文本 + 效果图 → 多张独立立面图

## 用途
接入效果图和立面文本，LLM 识别立面1/2/3并逐张生成独立立面图。用于从已有效果图反推各立面设计。

## 输入接口
- **立面文本**：每个立面的内容描述
- **效果图参考**：作为立面生成的视觉参考
- **立面形式参考图**：可选，约束立面形式

## 主要控件
- **立面数量**：1/2/3，识别并生成立面数量
- **模型选择**：图像生成模型
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：多张立面图（按立面1/2/3顺序）
`,"exhibition-text-image-loop":`# 图文循环器

> 同步接入文本和图像素材集，按一一配对 / 短集循环 / 全组合驱动下游展陈生图节点

## 用途
当上游文本和图像素材数量不一致时，用此节点对齐后驱动下游。支持三种配对模式，是展陈批量生图工作流的枢纽节点。

## 输入接口
- **文本素材集**：多段文本
- **图像素材集**：多张图像

## 主要控件
- **配对模式**：
  - 一一配对：按序号配对，超出部分丢弃
  - 短集循环：以较短素材集为基准，较长素材集循环
  - 全组合：笛卡尔积，每个文本配每张图
- **输出顺序**：可调整文本/图像的输出端口顺序

## 输出
- 文本端口：配对后的文本（每次运行输出一对）
- 图像端口：配对后的图像（每次运行输出一张）
`,"exhibition-outline-split":`# 展陈大纲拆分

> 读取展陈资料文档，按指定单元数或自动模式拆分大纲并提炼总结，输出多段文本

## 用途
把长篇展陈资料（大纲、策划案、说明文档）按展区/单元拆分成多段文本，便于下游节点逐段处理。

## 输入接口
- **文档**：DOCX / PDF / TXT
- **文本**：可选补充文本

## 主要控件
- **拆分模式**：
  - 指定单元数：按固定数量拆分
  - 自动：LLM 自动识别展区边界
  - 段落 / 行 / 正则 / 自定义分隔符 / 字数：通用文本拆分
- **单元数**：指定模式下拆分的目标数量
- **LLM 模型**：用于内容总结提炼
- **收藏**：常用拆分配置可保存为预设

## 输出
- 文本端口：多段拆分后的大纲文本（素材集）
`,"unit-panel-design":`# 单元板设计

> 生成单元板/整套板式设计图：文字提炼、多语言排序、材质选择、色材参考、尺寸标注，以及互斥的原生/FHL 生图模块

## 用途
生成展陈单元板设计图（展板、说明牌、导览牌等）。包含文字提炼、多语言排版、材质选择、色彩参考和尺寸标注全流程。

## 输入接口
- **文本素材**：单元板需要展示的内容文本
- **色彩与材质参考图**：可选。连接后会覆盖手动材质和字体约束，并自动读取主色调；FHL 模块生效时还会自动从文生图切换为参考图编辑。

## 主要控件
- **文字提炼级别**：一级 / 二级（二级更精炼）
- **多语言**：中 / 英 / 日 / 韩 等，可多选并排序
- **材质选择**：亚克力 / 金属 / 木质 / 喷绘 等
- **色材参考**：色彩与材质预设
- **尺寸标注**：开关，开启后在图上标注尺寸

## 生图模块
- **原生生图模块**：保留原有生图平台、模型、1K / 2K / 4K 和输出格式设置。
- **FHL 生图模块**：使用应用设置中的 FHL Images worker，只提供规格、比例和保存格式。没有启用的 FHL worker 时会显示任务错误，不会自动改用原生模块。
- **设为生效 / 已生效**：两个模块互斥。点击未生效模块的“设为生效”即可切换；未生效模块的参数仍会保留，但控件不可操作。生成期间不能切换模块。
- **规格**：FHL 可选 2K 或 4K，默认 2K。4K 只会在明确选择后提交。
- **比例**：比例列表随规格和任务类型变化。连接色彩与材质参考图后，2K 会增加编辑模式支持的比例；切换规格或参考图导致原比例不可用时自动回到 16:9。
- **保存格式**：默认 JPG，也可选择 PNG。选择 JPG 时只保存并输出 JPG，选择 PNG 时只保存并输出 PNG。

## 使用步骤
1. 输入或连接文本，完成标题、正文、多语言、尺寸和材质设置。
2. 如需参考特定色彩或材质，连接“色彩与材质参考图”。
3. 在原生或 FHL 模块上点击“设为生效”，再设置当前模块参数。
4. 点击“生成单元板”。通过画布批量运行触发时，同样只会执行当前生效模块。

## 状态与结果
- FHL 任务会使用单任务、单并发执行，并在节点内显示进度和错误。
- 生成结果继续写入单元板图片输出，可传给下游图片节点，也会进入现有生成历史并播放完成提示音。
- 切换生图模块不会清除另一模块已保存的参数。

## 输出
- 图像端口：单元板设计图
`,"sculpture-relief-design":`# 雕塑/浮雕设计

> 展陈雕塑与浮雕设计：文案提炼、类型选择、尺寸材质控制和参考图案轮廓约束

## 用途
生成展陈空间中的雕塑与浮雕设计方案。支持文案提炼、类型选择、尺寸材质控制和参考图案轮廓约束。

## 输入接口
- **文本素材**：雕塑/浮雕的主题描述
- **参考图案**：可选，约束轮廓形状

## 主要控件
- **类型**：圆雕 / 浮雕（高浮雕 / 浅浮雕）
- **尺寸**：长 / 宽 / 高
- **材质**：青铜 / 石材 / 树脂 / 不锈钢 等
- **轮廓约束**：开关，开启后参考图案约束轮廓
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：雕塑/浮雕设计图
`,"exhibition-wayfinding-design":`# 导视系统设计

> 博物馆室内外导视系统：导览标牌、方向牌、楼层索引、无障碍与安全导视的规范图和效果图生成

## 用途
生成博物馆/展馆的导视系统设计图，包含导览标牌、方向牌、楼层索引、无障碍与安全导视的规范图和效果图。

## 输入接口
- **文本素材**：导视内容（楼层 / 区域 / 方向信息）
- **建筑参考图**：可选，建筑空间作为导视位置参考

## 主要控件
- **导视类型**：导览标牌 / 方向牌 / 楼层索引 / 无障碍 / 安全
- **输出形式**：规范图 / 效果图
- **材质**：亚克力 / 金属 / 喷绘
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：导视系统设计图
`,"exhibition-scene-design":`# 场景设计

> 展馆场景设计：场景分类、整体环境参考、人物道具 @ 引用和图像生成

## 用途
生成展馆中的场景设计（场景化展项、复原场景、沉浸式空间）。支持场景分类、整体环境参考、人物道具 @ 引用。

## 输入接口
- **文本素材**：场景主题与内容描述
- **整体环境参考图**：可选，场景环境视觉参考
- **人物参考**：@ 引用其他节点的人物素材
- **道具参考**：@ 引用其他节点的道具素材

## 主要控件
- **场景分类**：历史复原 / 自然场景 / 科技场景 / 沉浸式 等
- **人物引用**：通过 @ 语法引用其他节点输出
- **道具引用**：同上
- **图像尺寸**：1K / 2K / 4K
- **模型选择**：图像生成模型

## 输出
- 图像端口：场景设计效果图
`,"science-exhibit-design":`# 科技展项设计

> 科技馆展项设计：LLM 提炼真实科学原理与参数，一键生成效果图、爆炸图、原理图、三视图和参数表

## 用途
面向科技馆展项的全方位设计节点。LLM 提炼真实科学原理与参数，一键生成效果图、爆炸图、原理图、三视图和参数表。

## 输入接口
- **文本素材**：展项主题、科学原理、目标受众

## 主要控件
- **科学原理**：LLM 自动提炼 / 手动指定
- **输出类型**（多选）：
  - 效果图：展项外观
  - 爆炸图：内部结构分解
  - 原理图：科学原理示意
  - 三视图：正视 / 侧视 / 顶视
  - 参数表：尺寸 / 材料 / 电气参数
- **LLM 模型**：用于原理提炼
- **图像模型**：用于生图
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：所选类型的多种设计图
- 文本端口：参数表
`,"showcase-interior-design":`# 柜内设计

> 展柜内部陈列设计：展柜尺寸、展品图与展品高度、色彩材质预设、尺寸标注和爆炸图输出

## 用途
设计展柜内部陈列。包含展柜尺寸、展品图与展品高度、色彩材质预设、尺寸标注和爆炸图输出。

## 输入接口
- **展品图**：需陈列的展品图像
- **展柜参考**：可选，展柜外观参考

## 主要控件
- **展柜尺寸**：长 / 宽 / 高
- **展品高度**：展品摆放高度
- **色彩材质预设**：展柜内壁 / 台面 / 灯光色温
- **尺寸标注**：开关
- **爆炸图**：开关，开启后额外输出爆炸图
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：柜内陈列设计图
- 图像端口：爆炸图（开关开启时）
`,"reverse-isometric-design":`# 反推轴侧

> 以平面布局为不可变结构基准，将展项效果图手动排版后生成无顶整体展陈轴侧图。

## 输入接口
- **平面布局图**：必填、单连接排他；墙柱、出入口、门窗均被锁定
- **展项效果图**：必填，可连接多张

## 主要控件
- **手动排版**：位移、旋转、等比缩放、横纵拉伸、源图裁剪和层级调整
- **展厅长宽**：在手动排版编辑窗口设置，底面直接显示长宽尺寸线，空白矩形按实际长宽比例显示
- **轴侧方向**：左前 / 右前 / 左后 / 右后
- **视角**：固定采用约 25°–30°低俯角，避免接近顶视图
- **展厅净高**：2400–12000 mm
- **地面材质**：20 种常用展厅地材
- **模型与尺寸**：复用展陈工具通用生图平台、模型、比例与尺寸

## 输出
- 输出一张无顶整体轴侧图；墙、柱、出入口、门窗保护由生成 Prompt 约束
- 靠墙展项保持背面贴墙、底部落地、立面竖直，不把参考图片平铺到地面或台面
`,"fusion-render-design":`# 融合效果图

> 根据展馆类型、展厅主体和空间参考图自动设计展厅，并将多张展项效果图作为素材自然融入。

## 输入接口
- **空间参考图**：可选、单连接排他；只约束空间面积感、长宽比例、面积与高度比例、墙柱开口、边界和纵深，不参与设计语言、色材、灯光或氛围
- **展项效果图**：必填，可连接多张

## 主要控件
- **展厅净高与地面材质**：控制空间尺度和地面表现
- **色彩与材质预设**：复用展陈图生图的共享预设库、分组选择器和手动补充数据
- **同时影响展项色调**：默认关闭；开启后预设同步影响展项冷暖、明暗、饱和度和材质观感
- **顶部工艺**：默认根据全部展项风格自动调整，也可指定 20 种常用展厅顶部工艺
- **地面材质**：第一项“根据展项来设计”，也可指定 20 种常用展厅地面材质
- **模型与尺寸**：选择生图平台、模型、比例、尺寸、Seed 与输出格式

## 输出
- 输出一张连续完整、真实光照、尺度可信的展陈空间效果图
- 空间参考图严格锁定空间比例，节点净高是唯一绝对高度基准并优先于参考图视觉高度
- 自动根据全部展项风格补齐协调的墙面、顶部、灯光、色材和克制的环境陈设，使展厅真实自然
- 所有可见墙面必须有与展馆类型和展项主题相符的图文、材质、灯光或异形结构设计，禁止大面积无内容墙面
- 以指定类型和主体的完整展厅效果图为生成重点，接入展项作为素材自动完成专业布置并融入空间
- 相机保持 1.4–1.6 米低人眼视角，不为展示全部展项而抬高；允许符合真实空间关系的自然遮挡
- 仅在大面积空档补充同类型次要科技展项或异形图文墙，并放在远端进行景深虚化
- 环境只衬托已有主展项，不新增抢主体的主要展项或大型主题装置
- 不输出平面图、轴侧图、拼版、技术图纸或文字说明
`,"cinema-auditorium-design":`# 影院报告厅设计

> 影院、报告厅和特效影院空间设计：长宽高、银幕舞台方向、色彩材质预设，输出效果图、彩平图和系统设备原理图

## 用途
设计影院、报告厅和特效影院空间。支持长宽高、银幕/舞台方向、色彩材质预设，输出效果图、彩平图和系统设备原理图。

## 输入接口
- **文本素材**：空间用途、座位数、放映设备等需求

## 主要控件
- **空间类型**：普通影院 / IMAX / 报告厅 / 4D 影院 / 球幕
- **长宽高**：空间尺寸
- **银幕方向**：前/后/左/右
- **舞台**：有/无，舞台位置
- **色彩材质预设**：座椅 / 墙面 / 地面 / 顶面
- **输出类型**（多选）：
  - 效果图
  - 彩平图
  - 系统设备原理图
- **图像尺寸**：1K / 2K / 4K

## 输出
- 图像端口：所选类型的多种设计图
`},Je=/^```/,bt=/^(#{1,3})\s+(.*)$/,Ge=/^\s*[-*]\s+(.*)$/,De=/^\s*(\d+)\.\s+(.*)$/,Ue=/^>\s?(.*)$/;function ie(e,t){const i=[],r=[],o=/`([^`]+)`/;let c=e,a;for(;(a=o.exec(c))!==null;){const l=r.length;r.push(a[1]),c=c.slice(0,a.index)+`\0CODE${l}\0`+c.slice(a.index+a[0].length)}return c.split(/(\*\*[^*]+\*\*)/g).forEach((l,d)=>{if(!l)return;const k=`${t}-inline-${d}`;if(l.startsWith("**")&&l.endsWith("**")&&l.length>4){i.push(n.jsx("strong",{children:l.slice(2,-2)},k));return}l.replace(/\u0000CODE(\d+)\u0000/g,(w,x)=>`${x}`).split(/\u0001(\d+)\u0001/g).forEach((w,x)=>{w&&(/^\d+$/.test(w)?i.push(n.jsx("code",{className:"t8-md-code-inline",children:r[Number(w)]},`${k}-code-${x}`)):i.push(n.jsx("span",{children:w},`${k}-text-${x}`)))})}),i}function Vn(e){const t=e.replace(/\r\n/g,`
`).split(`
`),i=[];let r=0;for(;r<t.length;){const o=t[r];if(Je.test(o)){const l=o.match(/^```(\S*)/),d=(l==null?void 0:l[1])||"",k=[];for(r+=1;r<t.length&&!Je.test(t[r]);)k.push(t[r]),r+=1;r+=1,i.push({type:"code",lang:d,text:k.join(`
`)});continue}if(!o.trim()){r+=1;continue}const c=o.match(bt);if(c){i.push({type:"heading",level:c[1].length,text:c[2].trim()}),r+=1;continue}const a=o.match(Ue);if(a){const l=[a[1]];for(r+=1;r<t.length;){const d=t[r].match(Ue);if(!d)break;l.push(d[1]),r+=1}i.push({type:"quote",text:l.join(" ")});continue}if(Ge.test(o)){const l=[];for(;r<t.length;){const d=t[r].match(Ge);if(!d)break;l.push(d[1].trim()),r+=1}i.push({type:"ul",items:l});continue}if(De.test(o)){const l=[];for(;r<t.length;){const d=t[r].match(De);if(!d)break;l.push(d[2].trim()),r+=1}i.push({type:"ol",items:l});continue}const f=[o];for(r+=1;r<t.length;){const l=t[r];if(!l.trim()||Je.test(l)||bt.test(l)||Ge.test(l)||De.test(l)||Ue.test(l))break;f.push(l),r+=1}i.push({type:"paragraph",text:f.join(`
`)})}return i}function qn(e){return!e||!e.trim()?[n.jsx("p",{className:"t8-md-empty text-white/40",children:"暂无帮助内容"},"empty")]:Vn(e).map((i,r)=>{const o=`md-block-${r}`;switch(i.type){case"heading":{const c=i.level===1?"t8-md-h1":i.level===2?"t8-md-h2":"t8-md-h3";return i.level===1?n.jsx("h1",{className:c,children:ie(i.text||"",o)},o):i.level===2?n.jsx("h2",{className:c,children:ie(i.text||"",o)},o):n.jsx("h3",{className:c,children:ie(i.text||"",o)},o)}case"ul":return n.jsx("ul",{className:"t8-md-ul",children:i.items.map((c,a)=>n.jsx("li",{children:ie(c,`${o}-li-${a}`)},`${o}-li-${a}`))},o);case"ol":return n.jsx("ol",{className:"t8-md-ol",children:i.items.map((c,a)=>n.jsx("li",{children:ie(c,`${o}-li-${a}`)},`${o}-li-${a}`))},o);case"quote":return n.jsx("blockquote",{className:"t8-md-quote",children:ie(i.text||"",o)},o);case"code":return n.jsx("pre",{className:"t8-md-pre",children:n.jsx("code",{className:"t8-md-code-block",children:i.text})},o);case"paragraph":default:{const a=(i.text||"").split(`
`);return n.jsx("p",{className:"t8-md-p",children:a.map((f,l)=>n.jsxs("span",{children:[l>0&&n.jsx("br",{}),ie(f,`${o}-p-${l}`)]},`${o}-p-${l}`))},o)}}})}const re={},Ie={};async function Xn(e){if(e in re)return re[e];if(e in Ie)return Ie[e];const t=(async()=>{try{const i=await hn(e),r=i&&i.trim()?i:Ve[e]||"";return re[e]=r,r}catch{const i=Ve[e]||"";return re[e]=i,i}finally{delete Ie[e]}})();return Ie[e]=t,t}function ps(e){e?delete re[e]:Object.keys(re).forEach(t=>delete re[t])}function ms({open:e,onClose:t,nodeType:i}){const[r,o]=v.useState(""),[c,a]=v.useState(!1),[f,l]=v.useState(!1),d=dn(i),k=(d==null?void 0:d.label)||i,p=(d==null?void 0:d.description)||"";return v.useEffect(()=>{if(!e)return;let m=!1;return a(!0),o(""),Xn(i).then(w=>{m||(o(w),l(!!w&&w!==Ve[i]),a(!1))}),()=>{m=!0}},[e,i]),v.useEffect(()=>{if(!e)return;const m=w=>{w.key==="Escape"&&(w.stopPropagation(),t())};return document.addEventListener("keydown",m,!0),()=>document.removeEventListener("keydown",m,!0)},[e,t]),e?ce.createPortal(n.jsx("div",{className:"t8-node-help-modal-mask",onMouseDown:m=>{m.target===m.currentTarget&&t()},children:n.jsxs("div",{className:"t8-node-help-modal",role:"dialog","aria-modal":"true",children:[n.jsxs("div",{className:"t8-node-help-modal-header",children:[n.jsx(pn,{size:16,className:"text-cyan-300 shrink-0"}),n.jsxs("div",{className:"flex-1 min-w-0",children:[n.jsx("div",{className:"t8-node-help-modal-title",children:k}),p&&n.jsx("div",{className:"t8-node-help-modal-subtitle",children:p})]}),n.jsx("button",{type:"button",className:"t8-node-help-modal-close",onClick:t,"aria-label":"关闭帮助",children:n.jsx(Ce,{size:16})})]}),n.jsx("div",{className:"t8-node-help-modal-body",children:c?n.jsxs("div",{className:"flex items-center justify-center py-10 text-white/50",children:[n.jsx(mn,{size:18,className:"animate-spin mr-2"})," 加载帮助内容..."]}):n.jsx("div",{className:"t8-md-content",children:qn(r)})}),n.jsxs("div",{className:"t8-node-help-modal-footer",children:[n.jsx("span",{children:f?"已使用自定义帮助文档":"使用内置默认帮助文档"}),n.jsx("span",{children:"可在 API 设置 → 节点帮助文档 中编辑"})]})]})}),document.body):null}export{ns as B,ts as C,Ve as D,_n as I,us as L,ms as N,wn as P,ds as a,En as b,es as c,We as d,rs as e,cs as f,ps as g,is as h,os as i,ls as j,as as k,Ee as p,qn as r,ss as s};
